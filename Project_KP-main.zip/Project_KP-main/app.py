# app.py
from flask import Flask, render_template, jsonify
import mysql.connector
from contextlib import closing

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

# =========================
# 1) KONEKSI + HELPER QUERY
# =========================
def get_db_connection():
    """
    Koneksi MySQL ke database umkm_db.
    Pakai pool kecil supaya efisien.
    """
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="",
        database="umkm_db",
        pool_name="umkm_pool",
        pool_size=5,
        autocommit=True,
    )

def q_all(sql, params=()):
    """Ambil banyak baris (list of dict)."""
    cnx = get_db_connection()
    try:
        with closing(cnx.cursor(dictionary=True)) as cur:
            cur.execute(sql, params)
            return cur.fetchall()
    finally:
        cnx.close()

def q_one(sql, params=()):
    """Ambil satu baris (dict) atau None."""
    rows = q_all(sql, params)
    return rows[0] if rows else None

def c(sql, params=()):
    """Helper hitung aman -> integer."""
    try:
        row = q_one(sql, params)
        return row["c"] if row and "c" in row else 0
    except:
        return 0

# ================
# 2) ROUTES UTAMA
# ================
@app.route('/')
def dashboard():
    # masih dummy sementara
    total_aktif = 25
    izin_koperasi_disetujui = 23
    return render_template(
        'dashboard.html',
        total_aktif=total_aktif,
        izin_koperasi_disetujui=izin_koperasi_disetujui
    )

@app.route('/koperasi-disetujui')
def koperasi_disetujui():
    try:
        data = q_all("SELECT tahun, jumlah_disetujui FROM izin_koperasi ORDER BY tahun")
    except Exception as e:
        print("Error izin_koperasi:", e)
        data = []
    return render_template("koperasi_disetujui.html", data=data)

@app.route('/umkm-aktif')
def daftar_umkm():
    # contoh dummy
    data_umkm = [
        {"nama": "Eka Ayu Fitri Anggraini","nama_umkm": "Chessy Kitchen","nik": "3525156905870002","alamat": "Bulak Rukem Timur 2-A/42","produk": "Boba drink, Burger & snack","status": "Aktif"},
        {"nama": "Murtosiyah","nama_umkm": "Depot Jeng Mur","nik": "3578295211730001","alamat": "Bulak Cumpat Barat no 23","produk": "Makanan dan minuman","status": "Aktif"},
    ]
    return render_template("umkm_aktif.html", data_umkm=data_umkm)

@app.route("/bidang_koperasi")
def bidang_koperasi():
    # helper count aman
    def c(sql):
        try:
            row = q_one(sql)
            return row["c"] if row and "c" in row else 0
        except:
            return 0

    data = {
        "jumlah_umkm":           c("SELECT COUNT(*) c FROM jumlah_umkm"),
        "jumlah_umkm_binaan":    c("SELECT COUNT(*) c FROM `jumlah umkm binaan`"),
        "sertifikasi_halal":     c("SELECT COUNT(*) c FROM sertifikasi_halal"),
        "kategori_produk_umkm":  c("SELECT COALESCE(SUM(jumlah),0) c FROM v_jumlah_kategori_produk"),
        "umkm_nib":              c("SELECT COUNT(*) c FROM umkm_nib"),
        "sertifikasi_merek":     c("SELECT COUNT(*) c FROM sertifikasi_merek"),
        "umkm_peken":            c("SELECT COUNT(*) c FROM umkm_peken"),

        # << ini yang penting: ambil dari tabel jumlah_pedagang_swk
        "pedagang_swk":          c("SELECT COUNT(*) c FROM `jumlah_pedagang_swk`"),

        # sisanya masih dummy
        "stan_swk_kosong":       100,
        "umkm_diintervensi":     30,
        "koperasi_aktif":        700,
        "koperasi_tidak_aktif":  600,
        "koperasi_diintervensi": 300,
    }
    return render_template("bidang_koperasi.html", data=data)


@app.route("/usaha_mikro")
def usaha_mikro():
    return render_template("usaha_mikro.html")

@app.route("/distribusi_perdagangan")
def distribusi_perdagangan():
    return render_template("distribusi_perdagangan.html")

@app.route("/pembinaan_perdagangan")
def pembinaan_perdagangan():
    return render_template("pembinaan_perdagangan.html")

@app.route("/uptd_metrologi")
def uptd_metrologi():
    return render_template("uptd_metrologi.html")

@app.route('/komoditas')
def komoditas():
    try:
        rows = q_all("SELECT id, nama_komoditas FROM komoditas ORDER BY id")
    except Exception as e:
        print("Error saat ambil data komoditas:", e)
        rows = []
    return render_template('komoditas.html', data=rows)

# ============================
# 3) ROUTES BIDANG KOPERASI
# ============================
@app.route("/bidang-koperasi/jumlah-umkm")
def jumlah_umkm_page():
    rows = q_all("""
        SELECT id, nama_pelaku_usaha, nama_usaha, no_telp, kelurahan, kecamatan
        FROM jumlah_umkm
        ORDER BY nama_pelaku_usaha
    """)
    return render_template("jumlah_umkm.html", rows=rows)

@app.route("/bidang-koperasi/kategori-produk")
def kategori_produk():
    rows = q_all("SELECT kategori, jumlah FROM v_jumlah_kategori_produk ORDER BY kategori")
    return render_template("kategori_produk.html", rows=rows)

@app.route("/umkm-binaan")
def umkm_binaan():
    rows = q_all("""
        SELECT kelurahan, kecamatan, alamat_domisili, alamat_tempat_usaha, no_telp
        FROM `jumlah umkm binaan`
        ORDER BY kelurahan, kecamatan
    """)
    return render_template("umkm_binaan.html", rows=rows)

@app.route("/sertifikasi-halal")
def sertifikasi_halal():
    rows = q_all("""
        SELECT
          nama_pelaku_usaha  AS nama_orang,
          nama_umkm          AS nama_umkm,
          nomor_sertifikat   AS sertifikat_halal
        FROM sertifikasi_halal
        ORDER BY nama_pelaku_usaha
    """)
    return render_template("sertifikasi_halal.html", rows=rows)

@app.route("/umkm-nib")
def umkm_nib():
    rows = q_all("""
        SELECT
          COALESCE(j.nama_pelaku_usaha, '(belum tertaut)') AS nama_orang,
          COALESCE(j.nama_usaha, '(belum tertaut)')        AS nama_umkm,
          n.nomor_nib,
          j.no_telp
        FROM umkm_nib n
        LEFT JOIN jumlah_umkm j ON j.id = n.jumlah_umkm_id
        ORDER BY n.id DESC
    """)
    return render_template("umkm_nib.html", rows=rows)

@app.route("/sertifikasi-merek")
def sertifikasi_merek_page():
    try:
        rows = q_all("""
            SELECT
              m.id,
              j.nama_pelaku_usaha   AS nama_orang,
              j.nama_usaha          AS nama_umkm,
              m.nama_brand,
              m.nomor_sertifikat_merek,
              m.kelas_merek,
              m.jenis_merek,
              m.status,
              DATE_FORMAT(m.tgl_pengajuan,  '%Y-%m-%d') AS tgl_pengajuan,
              DATE_FORMAT(m.tgl_terbit,     '%Y-%m-%d') AS tgl_terbit,
              DATE_FORMAT(m.berlaku_sampai, '%Y-%m-%d') AS berlaku_sampai,
              j.no_telp
            FROM sertifikasi_merek m
            LEFT JOIN jumlah_umkm j ON j.id = m.jumlah_umkm_id
            ORDER BY COALESCE(m.tgl_terbit, m.tgl_pengajuan) DESC, m.id DESC
        """)
    except Exception as e:
        print("Error SELECT sertifikasi_merek:", e)
        rows = []
    return render_template("sertifikasi_merek.html", rows=rows)

# Ringkasan angka (opsional / untuk API kecil)
@app.route("/ringkas")
def ringkas():
    return jsonify(dict(
        total_umkm=c("SELECT COUNT(*) c FROM jumlah_umkm"),
        umkm_binaan=c("SELECT COUNT(*) c FROM `jumlah umkm binaan`"),
        sertifikasi_halal=c("SELECT COUNT(*) c FROM sertifikasi_halal"),
        umkm_nib=c("SELECT COUNT(*) c FROM umkm_nib"),
    ))

# ====== UMKM PEKEN (FIX TANPA nama_umkm) ======
@app.route("/umkm-peken")
def umkm_peken_list():
    rows = q_all("""
        SELECT
            no,
            COALESCE(nama_orang_fix, nama_orang) AS nama_orang,
            kelurahan,
            kecamatan
        FROM umkm_peken
        ORDER BY no
    """)
    return render_template("umkm_peken.html", rows=rows)

# ===== Pedagang SWK =====
@app.route("/pedagang-swk")
def pedagang_swk_page():
    """
    Menampilkan daftar pedagang SWK dari tabel `jumlah _pedagang_swk`.
    Kolom yang diambil: nama_orang, Jenis_kelamin, nama_usaha.
    """
    rows = q_all("""
        SELECT
          nama_orang,
          Jenis_kelamin,
          nama_usaha
        FROM `jumlah_pedagang_swk`
        ORDER BY nama_orang
    """)
    return render_template("jumlah_pedagang_swk.html", rows=rows)


# =========
# 4) RUN
# =========
if __name__ == "__main__":
    app.run(debug=True)
