<<<<<<< HEAD
<!-- Tambahkan Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// ====== Intervensi UMKM sesuai LPPD (Line) ======
const ctx1 = document.getElementById('umkmChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: {
        labels: [2021, 2022, 2023, 2024, 2025],
        datasets: [{
            label: 'Jumlah UMKM',
            data: [50, 40, 360, 430, 250],
            borderColor: 'rgba(37, 99, 235, 1)',
            backgroundColor: 'rgba(37, 99, 235, 0.2)',
            borderWidth: 2,
            tension: 0.3
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// ====== Jenis Usaha UMKM (Doughnut) ======
const ctx2 = document.getElementById('jenisUsahaChart').getContext('2d');
new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['Kuliner', 'Fashion', 'Kerajinan', 'Jasa', 'Pertanian'],
        datasets: [{
            data: [50, 80, 100, 150, 120],
            backgroundColor: ['#3b82f6', '#22c55e', '#facc15', '#06b6d4', '#ef4444'],
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// ====== Contoh Chart Tambahan (Bar) ======
const ctx3 = document.getElementById('barChart').getContext('2d');
new Chart(ctx3, {
    type: 'bar',
    data: {
        labels: ['A', 'B', 'C', 'D', 'E'],
        datasets: [{
            label: 'Data Bar',
            data: [12, 19, 3, 5, 2],
            backgroundColor: '#10b981'
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// ====== Contoh Chart Tambahan (Pie) ======
const ctx4 = document.getElementById('pieChart').getContext('2d');
new Chart(ctx4, {
    type: 'pie',
    data: {
        labels: ['X', 'Y', 'Z'],
        datasets: [{
            data: [30, 40, 30],
            backgroundColor: ['#f59e0b', '#3b82f6', '#ef4444']
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});
</script>
=======
// Jalankan hanya setelah DOM siap
document.addEventListener("DOMContentLoaded", function () {

  // === Grafik Tren UMKM ===
  const umkmCanvas = document.getElementById('umkmChart');
  if (umkmCanvas) {
    const umkmCtx = umkmCanvas.getContext('2d');
    fetch('umkm.php')
    new Chart(umkmCtx, {
      type: 'bar',
      data: {
        labels: ['2020', '2021', '2022', '2023', '2024'],
        datasets: [{
          label: 'Jumlah UMKM Terdaftar',
          data: [240, 300, 370, 450, 520],
          backgroundColor: 'rgba(40, 167, 69, 0.7)'
        }]
      },
      options: {
        responsive: true,
        scales: {
          y: {
            beginAtZero: true
          }
        }
      }
    });
  }

  // === Jenis Usaha UMKM (Doughnut) ===
  const usahaCanvas = document.getElementById('jenisUsahaChart');
  if (usahaCanvas) {
    const usahaCtx = usahaCanvas.getContext('2d');
    new Chart(usahaCtx, {
      type: 'doughnut',
      data: {
        labels: ['Kuliner', 'Fashion', 'Kerajinan', 'Jasa', 'Pertanian'],
        datasets: [{
          label: 'Persentase',
          data: [35, 25, 20, 10, 10],
          backgroundColor: [
            '#007bff',
            '#28a745',
            '#ffc107',
            '#17a2b8',
            '#dc3545'
          ],
          borderColor: '#fff',
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          },
          tooltip: {
            callbacks: {
              label: function (context) {
                return `${context.label}: ${context.parsed}%`;
              }
            }
          }
        }
      }
    });
  }

  // === Kategori UMKM (Pie) ===
  const kategoriCanvas = document.getElementById('kategoriPieChart');
  if (kategoriCanvas) {
    const kategoriCtx = kategoriCanvas.getContext('2d');
    new Chart(kategoriCtx, {
      type: 'pie',
      data: {
        labels: ['Mikro', 'Kecil', 'Menengah'],
        datasets: [{
          data: [60, 30, 10],
          backgroundColor: ['#4CAF50', '#FFC107', '#2196F3'],
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: { position: 'bottom' }
        }
      }
    });
  }

  // === Status Pengajuan (Horizontal Bar) + Dropdown Bulan ===
  const statusCanvas = document.getElementById('statusPengajuanChart');
  const bulanSelect = document.getElementById('bulanSelect');

  const dataPerBulan = {
    jan: [100, 50, 30],
    feb: [150, 60, 45],
    mar: [200, 70, 90],
    apr: [720, 120, 380],
    mei: [500, 200, 100],
    jun: [300, 150, 50]
  };

  if (statusCanvas && bulanSelect) {
    const statusCtx = statusCanvas.getContext('2d');
    let statusChart = new Chart(statusCtx, {
      type: 'bar',
      data: {
        labels: ['Disetujui', 'Ditolak', 'Diproses'],
        datasets: [{
          label: 'Jumlah Pengajuan',
          data: dataPerBulan[bulanSelect.value],
          backgroundColor: ['#28a745', '#dc3545', '#ffc107']
        }]
      },
      options: {
        responsive: true,
        indexAxis: 'y',
        scales: {
          x: {
            beginAtZero: true
          }
        },
        plugins: {
          legend: { display: false },
          tooltip: {
            callbacks: {
              label: function (context) {
                return `${context.label}: ${context.parsed} pengajuan`;
              }
            }
          }
        }
      }
    });

    bulanSelect.addEventListener('change', function () {
      const selected = bulanSelect.value;
      statusChart.data.datasets[0].data = dataPerBulan[selected];
      statusChart.update();
    });
  }

  // === Peta Leaflet ===
  const mapDiv = document.getElementById('petaKegiatan');
  if (mapDiv) {
    const map = L.map('petaKegiatan').setView([-7.2575, 112.7521], 12); // Koordinat Surabaya
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Tambahkan marker contoh
    L.marker([-7.2504, 112.7688]).addTo(map)
      .bindPopup('<b>Kegiatan UMKM</b><br>Kecamatan Genteng');
    L.marker([-7.2756, 112.6426]).addTo(map)
      .bindPopup('<b>Kegiatan UMKM</b><br>Kecamatan Lakarsantri');
  }

});
>>>>>>> 13018e0d78f74eb244047067fa8c79702d50b3ba
