-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2025 at 01:21 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `umkm_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `jumlah umkm binaan`
--

CREATE TABLE `jumlah umkm binaan` (
  `id` int(10) UNSIGNED NOT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `alamat_domisili` varchar(255) DEFAULT NULL,
  `alamat_tempat_usaha` varchar(255) DEFAULT NULL,
  `no_telp` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jumlah umkm binaan`
--

INSERT INTO `jumlah umkm binaan` (`id`, `kelurahan`, `kecamatan`, `alamat_domisili`, `alamat_tempat_usaha`, `no_telp`) VALUES
(1, 'Patemon', 'Sawahan', 'Patemon 3/66', 'Patemon 3/66', '85777845351'),
(2, 'Sawahan', 'Sawahan', 'Kedung Anyar 1/26-D RT 002 RW 012', 'Kedung Anyar 1/26-D RT 002 RW 012', '82229222055'),
(3, 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Banyu Urip Lor 10/68 RT 004 RW 006', '81223419108'),
(4, 'Sawahan', 'Sawahan', 'Haimun 14-A RT 001 RW 008', 'Haimun 14-A RT 001 RW 008', '81336442386'),
(5, 'Pakis ', 'Sawahan', 'Wonokitri 2/123 RT 004 RW 001', 'Wonokitri 2/123 RT 004 RW 001', '895321348181'),
(6, 'Sawahan', 'Sawahan', 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Kedung Anyar 9/16 RT 008 RW 003  ', '81315531522'),
(7, 'Petemon', 'Sawahan', 'Simo Sidomulyo GG 4 No14', 'Simo Sidomulyo GG 4 No14', '82331641822'),
(8, 'Petemon', 'Sawahan', 'Simo Sidomulyo I/12A', 'Jalan Petemon III No.35B', '82142944593'),
(9, 'Pakis ', 'Sawahan', 'Kembang Kuning Kramat 2/21-A', 'Kembang Kuning Kramat 2/21-A', '859555141899'),
(10, 'Pakis ', 'Sawahan', 'Dukuh Kupang Timur VI/3', 'Dukuh Kupang Timur VI/3', '85334730967'),
(11, 'Pakis ', 'Sawahan', 'Pakis Tirtosari 10/9', 'Pakis Tirtosari 10/9', '81358086683'),
(12, 'Putat Jaya', 'Sawahan', 'Banyu Urip Jaya 6/54', 'Banyu Urip Jaya 6/54', '081231377186'),
(13, 'Petemon', 'Sawahan', 'Petemon 4 No.93', 'Petemon 4 No.93', '082142215909'),
(14, 'sawahan', 'sawahan', 'Kedung Anyar 8/54-B', 'Kedung Anyar 8/54-B', '089516499572'),
(15, 'banyu urip', 'sawahan', 'Banyu Urip Kidul 2a/11', 'Banyu Urip Kidul 2a/11', '08817561929'),
(16, 'petemon', 'sawahan', 'Petemon 4/132a', 'Petemon 4/132a', '081230333352'),
(17, 'banyu urip', 'sawahan', 'Banyurip wetan4/32', 'Banyurip wetan4/32', '085748692784'),
(18, 'Putat Jaya', 'sawahan', 'Kupang Gunung Jaya 3/29', 'Kupang Gunung Jaya 3/29', '082141146564'),
(19, 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Selatan 2', 'Simo Gunung Kramat Selatan 2', '085757538321'),
(20, 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 5/59', 'Banyu Urip Kidul 5/59', '085850750563'),
(21, 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 2/18', 'Banyu Urip Lor 2/18', '082140992407'),
(22, 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 6G/8', 'Banyu Urip Kidul 6G/8', '083830191515'),
(23, 'petemon', 'Sawahan', 'Petemon 2/104-A', 'Petemon 2/104-A', '085606606655'),
(24, 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur III/15', 'Putat Jaya C Timur III/15', '\'081952772274'),
(25, 'sambikerep', 'sambikerep', 'Queens Town Q I/57', 'Queens Town Q I/57', '08113355772'),
(26, 'Pakis ', 'Sawahan', 'Wonokitri 2 No.116', 'Wonokitri 2 No.116', '081230786483'),
(27, 'Balongsari', 'Tandes', 'Balongsari Blok 4-G/5', 'Balongsari Blok 4-G/5', '085959915912'),
(28, 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Timur 1/30', 'Simo Gunung Kramat Timur 1/30', '081333243466'),
(29, 'Pakis ', 'Sawahan', 'Dukuh pakis 6D1-B No.3', 'Dukuh pakis 6D1-B No.3', '081234857424'),
(30, 'Sawahan', 'Sawahan', 'Kranggang Pangselan 5/14 ', 'Kranggang Pangselan 5/14 ', '082257776773'),
(31, 'Petemon', 'Sawahan', 'Petemon 2/84 B ', 'Petemon 2/84 B ', '081333275655'),
(32, 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 6/88', 'Banyu Urip Lor 6/88', '087852755388'),
(33, 'Banyu urip', 'Sawahan', 'Simo Gunung 1/20', 'Simo Gunung 1/20', '083830003029'),
(34, 'Banyu urip', 'Sawahan', 'Girilaya 2/31', 'Girilaya 2/31', '082139230529'),
(35, 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur 3/3', 'Putat Jaya C Timur 3/3', '081357822559'),
(36, 'Putat Jaya', 'Sawahan', 'Simo Gunung Baru Jaya Blok G1/10', 'Simo Gunung Baru Jaya Blok G1/10', '081235652676'),
(37, 'Putat Jaya', 'Sawahan', 'Kupang Gunung Timur 7 -B/45', 'Kupang Gunung Timur 7 -B/45', '087855549981'),
(38, 'Pakis ', 'Sawahan', 'Kembang Kuning Mulyo I No.4', 'Kembang Kuning Mulyo I No.4', '082233352380'),
(39, 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '082131345066'),
(40, 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '081334512300/0813315151'),
(41, 'Bendulmerisi ', 'wonocolo', 'Bendulmerisi Selatan 3/15', 'Bendulmerisi Selatan 3/15', '0821151111368'),
(42, 'Lakarsantri', 'Lakarsantri', 'Lakarsantri RT 2 RW 4', 'Lakarsantri RT 2 RW 4', '081336956366'),
(43, 'Lidah kulon', 'Lakarsantri', 'Royal Park 2 Blok TK 3-78', 'Royal Park 2 Blok TK 3-78', '081213819006'),
(44, 'Babat Jerawat ', 'Pakal', 'Griya Benowo Indah Blok C/7', 'Griya Benowo Indah Blok C/7', '087829722378'),
(45, 'Ngegel Rejo', 'Wonokromo', 'Ngagel Mulyo 16/65 B', 'Ngagel Mulyo 16/65 B', '082331445600'),
(46, 'Mojo ', 'Gubeng', 'Mojoarum 2/6', 'Mojoarum 2/6', '0895620107573'),
(47, 'Krembangan Selatan ', 'Krembangan', 'Kemayoran Masjid No.4', 'Kemayoran Masjid No.4', '088226368757'),
(48, 'Pakis ', 'Sawahan', 'Pakis Wetan 5/92A', 'Pakis Wetan 5/92A', '082142773005'),
(49, 'Tanah Kali kedinding', 'Kenjeran', 'Pogot Baru GG Karya Bakti No 12', 'Pogot Baru GG Karya Bakti No 12', '087854446874'),
(50, 'Babatan ', 'Wiyung ', 'Babatan Pratama Blok HH - 7 ', 'Babatan Pratama Blok HH - 7 ', '08155116119'),
(51, NULL, NULL, NULL, NULL, NULL),
(52, 'sidosermo', 'wonocolo', 'Bendul merisi No.134', 'Bendul merisi No.134', '081315380790'),
(53, 'Bendul merisi ', 'Wonocolo', 'Bendur Merisi Besar Sel 47 F', 'Bendur Merisi Besar Sel 47 F', '082337870972'),
(54, 'siwalankerto', 'Wonocolo', 'Siswalankerto 27B', 'Siswalankerto 27B', '082230769726'),
(55, 'Tembok Dukuh', 'Bubutan', 'Asem Bagus II/17-A', 'Asem Bagus II/17-A', '081331488441'),
(56, 'Wonorejo', 'Tegalsari ', 'Wonorejo 3/72 RT 004 RW 005 ', 'Wonorejo 3/72 RT 004 RW 005 ', '082257668188'),
(57, 'Gayungan ', 'Gayungan ', 'Gayungsari Barat 09/17 RT 003 RW 007 ', 'Gayungsari Barat 09/17 RT 003 RW 007 ', '082141560201'),
(58, 'Asemrowo ', 'Asemrowo', 'Tambak dalam Baru 3 No 27 RT 003 RW 005 ', 'Tambak dalam Baru 3 No 27 RT 003 RW 005 ', '085102242289'),
(59, 'Nginden Jangkungan ', 'Sukolilo ', 'Nginden Intan Utara No 48 RT 001 RW 009 ', 'Nginden Intan Utara No 48 RT 001 RW 009 ', '08113545227'),
(60, 'Karah ', 'Jambangan ', 'Perum Puri Kencana Karah B-19 RT 005 RW 011', 'Perum Puri Kencana Karah B-19 RT 005 RW 011', '08123251029'),
(61, 'Pagesangan ', 'Jambangan ', 'Jl Pagesangan IIIA/81 RT 004 RW 003 ', 'Jl Pagesangan IIIA/81 RT 004 RW 003 ', '0895429763355'),
(62, 'Kebonsari ', 'Jambangan ', 'Kebonsari Gg 5/7 - L RT 006 RW 002 ', 'Kebonsari Gg 5/7 - L RT 006 RW 002 ', '081234468480'),
(63, 'Manyar Sabrangan ', 'Mulyorejo ', 'Manyar sabrangan 6A/12 RT 002 RW 002', 'Manyar sabrangan 6A/12 RT 002 RW 002', '081249716911'),
(64, 'Simomulyo Baru ', 'Sukomanunggal ', 'Simo Pomahan 3/27 RT 009 RW 002 ', 'Simo Pomahan 3/27 RT 009 RW 002 ', '082142043600'),
(65, 'Sawunggaling ', 'Wonokromo ', 'Gajah Mada Baru 1/139 RT 009 RW 012 ', 'Gajah Mada Baru 1/139 RT 009 RW 012 ', '081235755770'),
(66, 'sidosermo', 'Wonocolo', 'Sidosermo Indah No 23 RT 001 RW 006 ', 'Sidosermo Indah No 23 RT 001 RW 006 ', '081231177447'),
(67, 'Sememi ', 'Benowo ', 'Perum Dreaming Land Blok D 6/10 RT 009 RW 004', 'Perum Dreaming Land Blok D 6/10 RT 009 RW 004', '087747778568'),
(68, 'Sememi ', 'Benowo ', 'Perum Dreaming Land Blok D3/9 RT 001 RW 010 ', 'Perum Dreaming Land Blok D3/9 RT 001 RW 010 ', '081252843750'),
(69, 'Sememi ', 'Benowo ', 'Sememi Jaya 4/6 RT 003 RW 001 ', 'Sememi Jaya 4/6 RT 003 RW 001 ', '081234668274'),
(70, 'Sememi ', 'Benowo ', 'Dreaming Land D6 No 2 RT 001 RW 010 ', 'Dreaming Land D6 No 2 RT 001 RW 010 ', '083833584130'),
(71, 'Babat Jerawat ', 'Pakal ', 'Pondok Benowo Indah Blok AD/10 RT 001 RW 006 ', 'Pondok Benowo Indah Blok AD/10 RT 001 RW 006 ', '08970890886'),
(72, 'Airlangga ', 'Gubeng ', 'Gubeng Kertajaya 5C/11 RT 004 RW 003 ', 'Gubeng Kertajaya 5C/11 RT 004 RW 003 ', '087763335481'),
(73, 'Ngagelrejo ', 'Wonokromo ', 'Ngagel Rejo 3B/19 RT 007 RW 002 ', 'Ngagel Rejo 3B/19 RT 007 RW 002 ', '085156888970'),
(74, 'Jagir ', 'Wonokromo ', 'Jagir Sidomukti 2/46 RT 002 RW 003 ', 'Jagir Sidomukti 2/46 RT 002 RW 003 ', '081235402058'),
(75, 'Jagir ', 'Wonokromo ', 'Gembili 2/23 RT 002 RW 007 ', 'Gembili 2/23 RT 002 RW 007 ', '087761613469'),
(76, 'Gebang Putih ', 'Sukolilo ', 'Gebanglor No. 50 A', 'Gebanglor No. 50 A', '087761801988'),
(77, NULL, NULL, NULL, NULL, NULL),
(78, 'Tanah Kali Kedinding ', 'Kenjeran ', 'Tanah merah 4 Semanggi No 48A RT 015 RW 004 ', 'Tanah merah 4 Semanggi No 48A RT 015 RW 004 ', '08999372988'),
(79, 'Manukan Kulon ', 'Tandes ', 'Manukan Krido Blok 4-l/10 RT 005 RW 006 ', 'Manukan Krido Blok 4-l/10 RT 005 RW 006 ', '082233360045'),
(80, 'Sawunggaling ', 'Wonokromo ', 'Brawijaya Kedurus 1/64 RT 004 RW 006 ', 'Brawijaya Kedurus 1/64 RT 004 RW 006 ', '081336351679/ 081290071626'),
(81, 'Darmo ', 'Wonokromo ', 'Lesti 71 RT 008 RW 007 ', 'Lesti 71 RT 008 RW 007 ', '082230433827'),
(82, 'Sidotopo wetan ', 'Kenjeran ', 'Bulak Banteng Wetang 6/36 RT 005 RW 008 ', 'Bulak Banteng Wetang 6/36 RT 005 RW 008 ', '08123530641'),
(83, 'Tegalsari ', 'Tegalsari ', 'Pandegiling 5/22 A RT 006 RW 007 ', 'Pandegiling 5/22 A RT 006 RW 007 ', '081916817409'),
(84, 'Peneleh ', 'Genteng ', 'Pakuwon indah, waterplace Tower A unit 1505 ', 'Pakuwon indah, waterplace Tower A unit 1505 ', '08113393663'),
(85, 'Kedungdoro ', 'Tegalsari ', 'Surabayan 4/20 RT 006 RW 002', 'Surabayan 4/20 RT 006 RW 002', '0895805314395'),
(86, 'Morokrembangan ', 'Krembangan ', 'Tambak Asri Putri Malu No 24 RT 010 RW 006 ', 'Tambak Asri Putri Malu No 24 RT 010 RW 006 ', '081216711561'),
(87, 'Ploso ', 'Tambak Sari ', 'Ploso 7/9 RT 007 RW 005 ', 'Ploso 7/9 RT 007 RW 005 ', '085730453106'),
(88, 'Manyar Sabrangan ', 'Mulyorejo ', 'Manyar Sabrangan 7/4 RT 002 RW 002 ', 'Manyar Sabrangan 7/4 RT 002 RW 002 ', '08819394045'),
(89, 'Ngagelrejo ', 'Wonokromo ', 'Ngagel mulyo 1/32 RT 017 RW 004 ', 'Ngagel mulyo 1/32 RT 017 RW 004 ', '081235468889'),
(90, 'Bulak ', 'Bulak ', 'Bulak rukem timur 2-K/15 RT 002 RW 007 ', 'Bulak rukem timur 2-K/15 RT 002 RW 007 ', '089691695757'),
(91, 'Kapasan ', 'Simokerto ', 'Gembong 3/5 RT 003 RW 004 ', 'Gembong 3/5 RT 003 RW 004 ', '083857075759'),
(92, 'Bulak ', 'Bulak ', 'Bulak Setro 3 No 10 B RT 001 RW 005 ', 'Bulak Setro 3 No 10 B RT 001 RW 005 ', '085815312434'),
(93, 'Sidosermo ', 'Wonocolo ', 'Sidosermo 2 Blok D No 7 RT 002 RW 004 ', 'Sidosermo 2 Blok D No 7 RT 002 RW 004 ', '085604086025'),
(94, 'Bendul merisi ', 'wonocolo ', 'Bendul Merisi Gg Besar Selatan 55 E RT 003 RW 006 ', 'Bendul Merisi Gg Besar Selatan 55 E RT 003 RW 006 ', '081231485266'),
(95, 'Perak Barat', 'Krembangan', 'Tanjung Karang 1/8', 'Tanjung Karang 1/8', '087889978365'),
(96, 'Bulak', 'Bulak', 'Bulak Cumpat Timur 3/17', 'Bulak Cumpat Timur 3/17', '085854514500'),
(97, 'Bulak', 'Bulak', 'Bulak Kalitinjang Baru 2/101', 'Bulak Kalitinjang Baru 2/101', '085792737916'),
(98, 'Sukolilo Baru', 'Bulak', 'Jl. Sukolilo 1B/2B', 'Jl. Sukolilo 1B/2B', '08223336468'),
(99, 'Bulak', 'Bulak', 'Bogorami Selatan 5/15', 'Bogorami Selatan 5/15', '081357755001'),
(100, 'Bulak', 'Bulak', 'Bulak Cumpat Utara 6 Blok 9', 'Bulak Cumpat Utara 6 Blok 9', '085713491224'),
(101, 'Kedung Cowek', 'Bulak', 'Jl. Nambangan Perak 9', 'Jl. Nambangan Perak 9', '085733832589'),
(102, 'Dukuh Setro', 'Tambaksari', 'Setro Baru Utara 9/47', 'Setro Baru Utara 9/47', '085100538558');

-- --------------------------------------------------------

--
-- Table structure for table `jumlah_pedagang_swk`
--

CREATE TABLE `jumlah_pedagang_swk` (
  `nama_orang` int(11) NOT NULL,
  `Jenis_kelamin` varchar(225) NOT NULL,
  `nama_usaha` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jumlah_pedagang_swk`
--

INSERT INTO `jumlah_pedagang_swk` (`nama_orang`, `Jenis_kelamin`, `nama_usaha`) VALUES
(1, 'PEREMPUAN', 'Kedai Jajanan\'s Bu Thiwuk 808 '),
(2, 'PEREMPUAN', 'tumbas jajan'),
(3, 'PEREMPUAN', 'KSM Familiy'),
(4, 'PEREMPUAN', 'Dapur Mamabi'),
(5, 'PEREMPUAN', 'Mentoel sawahan'),
(6, 'PEREMPUAN', 'bundaweny 16'),
(7, 'PEREMPUAN', 'Mie Ayam Pangsit Sidomulyo'),
(8, 'PEREMPUAN', 'Papin Foods And Drinks'),
(9, 'PEREMPUAN', 'RR21'),
(10, 'PEREMPUAN', 'Bu Ncik'),
(11, 'PEREMPUAN', 'Omah Klemben'),
(12, 'PEREMPUAN', 'DNCook'),
(13, 'Laki Laki', 'Dapur Yang Ti'),
(14, 'PEREMPUAN', 'Fiza Collection'),
(15, 'PEREMPUAN', 'BDS(Bakoel Duren Soerabaja)'),
(16, 'PEREMPUAN', 'Pari\'e Qu'),
(17, 'PEREMPUAN', 'Kenari\'s KUKER'),
(18, 'PEREMPUAN', 'Bun\'s Craft'),
(19, 'PEREMPUAN', 'Dapoerbundhae99'),
(20, 'PEREMPUAN', 'Obiesh Cake'),
(21, 'PEREMPUAN', 'Nombusi'),
(22, 'PEREMPUAN', 'Sarisol'),
(23, 'PEREMPUAN', 'Svedanika'),
(24, 'Laki Laki', '3 Putra 5758'),
(25, 'PEREMPUAN', 'Lilos\'s'),
(26, 'PEREMPUAN', 'Kedai Jajan caraki'),
(27, 'PEREMPUAN', 'D\'rezluck'),
(28, 'Laki Laki', 'Heru Fish Waffle'),
(29, 'Laki Laki', 'GLORIA88'),
(30, 'PEREMPUAN', 'Warunguntur 77'),
(31, 'PEREMPUAN', 'Zafir Style'),
(32, 'Laki Laki', 'Pastelikah'),
(33, 'PEREMPUAN', 'EMAK SIMO'),
(34, 'PEREMPUAN', 'NONA\'S FOOD'),
(35, 'PEREMPUAN', 'GENarta Collection'),
(36, 'PEREMPUAN', 'Sambal Bu Fatimah'),
(37, 'PEREMPUAN', 'Oemah Daharan'),
(38, 'PEREMPUAN', 'Mimi cakecookies'),
(39, 'PEREMPUAN', 'Wastra Bag'),
(40, 'PEREMPUAN', 'Ellegant Batik'),
(41, 'PEREMPUAN', 'Lieng Ows Tee'),
(42, 'Laki Laki', 'Benyamin Yacob'),
(43, 'PEREMPUAN', 'Mai Co Tailor'),
(44, 'PEREMPUAN', 'ZARARA BAKERY'),
(45, 'PEREMPUAN', 'La Tea Es Teh jumbo'),
(46, 'Laki Laki', 'Cahaya Baru'),
(47, 'PEREMPUAN', 'Dina Collection'),
(48, 'PEREMPUAN', 'Sastarasa Sebuah Karya rasa'),
(49, 'PEREMPUAN', 'Treepuspa'),
(50, 'Laki Laki', 'Griya Gemati '),
(51, '', ''),
(52, 'Laki Laki', 'Ben\'e-E Drink'),
(53, 'Laki Laki', 'Bandengku Bandeng Presto Bendul'),
(54, 'PEREMPUAN', 'Radjamoe'),
(55, 'PEREMPUAN', 'Glant & Co'),
(56, 'Perempuan', 'Roti Bakar BRO-SIS '),
(57, 'Perempuan', 'HEY Cincau!'),
(58, 'Laki Laki', 'WIL'),
(59, 'Perempuan', 'Memoire Haus '),
(60, 'Perempuan ', 'Auf Beauty '),
(61, 'Perempuan ', 'Cendol With You '),
(62, 'Laki Laki', 'Kaudhawa Tea '),
(63, 'Perempuan ', 'Zane '),
(64, 'Laki Laki', 'Kopi Grobar '),
(65, 'Perempuan ', 'Dapur Mak R.A '),
(66, 'Perempuan ', 'Rayu Manis '),
(67, 'Perempuan ', 'Dapur Budhe Dreamland '),
(68, 'Perempuan ', 'Dreamingland Snacks'),
(69, 'Perempuan ', 'Sri Wijaya 46 '),
(70, 'Perempuan ', 'DJP Dapuer Dwi JP '),
(71, 'Perempuan ', 'Dapur Mak Uniek '),
(72, 'Perempuan ', 'Siseru '),
(73, 'Perempuan ', 'LABAIK PIZZA '),
(74, '0', 'RAYFAN '),
(75, 'Perempuan ', 'Bilgharo Kitchen '),
(76, 'Perempuan', 'Dapur Icha'),
(77, 'Perempuan ', 'sunduk\'an sate kiandra '),
(78, 'Perempuan ', 'Mem Mem '),
(79, 'Laki laki ', 'Dimsum Dom '),
(80, 'Laki laki ', 'Juragan Kress& Sueger '),
(81, 'Perempuan ', 'Kedai Bu Mega '),
(82, 'Perempuan ', 'Kripik Singkong Mbak Ibad '),
(83, 'Perempuan ', 'Zumi'),
(84, 'Perempuan ', 'POY '),
(85, 'Laki laki ', 'Sweettlekid'),
(86, 'Perempuan ', 'Bida 2 Bakery '),
(87, 'Perempuan ', 'Dapur Canda'),
(88, 'Perempuan ', 'Sabeluh '),
(89, 'Perempuan ', 'Donsu Bomboloni '),
(90, 'Perempuan ', 'Onde onde Seribu Wijen '),
(91, 'Perempuan ', 'Hanny Kitchen '),
(92, 'Perempuan ', 'Kwita Bakery '),
(93, 'Perempuan ', 'Lima lima Nasi Kotak '),
(94, 'Perempuan', 'Fal-Zen'),
(95, 'Laki - laki', 'Gerai Jeng E\'eng'),
(96, 'Perempuan', 'Dapur Moms Rerey'),
(97, 'Perempuan', 'Toko Kerupuk Risma'),
(98, 'Perempuan', 'Griya Eonni'),
(99, 'Laki - laki', 'Sae Sari Kedelai'),
(100, 'Perempuan ', 'Cibuyam Suroboyo'),
(101, 'Perempuan ', 'Arinta'),
(102, 'Perempuan ', 'Lumpia Tol Simo'),
(103, 'Perempuan ', 'D\'Aruna'),
(104, 'Perempuan ', 'Catering D\'soetji'),
(105, 'Perempuan ', 'Japit Jajanan Dhe Piit'),
(106, 'Perempuan ', 'Kamila\'s Kitchen'),
(107, 'Perempuan ', 'Kedai Juwita'),
(108, 'Perempuan ', 'Pawon Nafisa'),
(109, 'Perempuan ', 'Pawon Yes'),
(110, 'Perempuan ', 'Pawon Daik'),
(111, 'Perempuan ', 'Hefira'),
(112, 'Perempuan ', 'Batagor Siomay Endangmami'),
(113, 'Perempuan ', 'TSELEM'),
(114, 'Perempuan ', 'Raja Bebek Jingkrak'),
(115, 'Perempuan ', 'Yo Juice'),
(116, 'Laki-laki', 'S\'POKAT'),
(117, 'Laki-laki', 'STARGRAND'),
(118, 'Perempuan ', 'Krunchini Mantapini'),
(119, 'Perempuan ', 'Roti Maryam RizQ'),
(120, 'Perempuan ', 'AYUSER'),
(121, 'Perempuan ', 'Ratu Cooking'),
(122, 'Perempuan ', 'Dapur Uti Queen'),
(123, 'Perempuan ', 'Doolyn House'),
(124, 'Perempuan ', 'Anna Que'),
(125, 'Perempuan ', 'Keuken De Yulya'),
(126, 'Perempuan ', 'Risollaris'),
(127, 'Perempuan ', 'Chiken Steak Bang Rafi'),
(128, 'Laki-laki', 'Kataluna Coffee'),
(129, 'Perempuan ', 'Bebek Kobong Suroboyo'),
(130, 'Perempuan ', 'd.mochiin'),
(131, 'Laki-laki', 'Oppikoppi'),
(132, 'Perempuan ', 'Mari\'S Cooking'),
(133, 'Perempuan ', 'Sekar Dewa'),
(134, 'Perempuan ', 'Tauwa Cak Ji'),
(135, 'Laki-laki', '0720 Since 2024'),
(136, 'Perempuan ', 'SIJIESEK'),
(137, 'Perempuan ', 'Njajan Rek'),
(138, 'Perempuan ', 'Dina Craft'),
(139, 'Perempuan ', 'DaputrTita'),
(140, 'Perempuan ', 'Rempahtera'),
(141, 'Perempuan ', 'Zameena Craft'),
(142, 'Perempuan ', 'YOICHISAKU'),
(143, 'Laki-laki', 'Chin Caow KeMah'),
(144, 'Perempuan ', 'Ayam Kremes Gembul'),
(145, 'Perempuan ', 'Almaritz Food'),
(146, 'Perempuan ', 'Blinjo Udang Manis AE'),
(147, 'Perempuan ', 'Pohong Keju Meletus'),
(148, 'Perempuan ', 'H&R Collection'),
(149, 'Perempuan ', 'Nasya Bakery House'),
(150, 'Perempuan ', 'i and Co '),
(151, 'Perempuan ', 'Grotto Rozano'),
(152, 'Perempuan ', 'Dapoer Safara'),
(153, 'Perempuan ', 'Marj'),
(154, 'Perempuan ', 'Classica cake & bakery '),
(155, 'laki-laki', 'Heerlijk Guna Guna'),
(156, 'Perempuan ', 'nobinobi kitchen'),
(157, 'Perempuan ', 'Pita Dolly'),
(158, 'Perempuan ', 'Daunloka'),
(159, 'Perempuan ', 'Rumah Oma'),
(160, 'Perempuan ', 'Lab Rasa'),
(161, 'Perempuan ', 'Dapur Markitut '),
(162, 'Perempuan ', 'Mama Idock Kitchen'),
(163, 'Perempuan ', 'Elly Zafri'),
(164, 'laki-laki', 'Seblak Om Kbd'),
(165, 'Perempuan ', 'STARTIC artistic eco fashion'),
(166, 'Perempuan ', 'FALIRA HOMEMADE'),
(167, 'Perempuan ', 'GLARA. CRAFT Real Flower Resin Art '),
(168, 'Perempuan ', 'Nunue Project Macrame'),
(169, 'Perempuan ', 'Jourell\'s Bakery By Gracia\'s'),
(170, 'Perempuan ', 'Que.San Kue & Snack'),
(171, 'Perempuan ', 'SR.Cookies By.Srirejeki'),
(172, 'laki-laki', 'Prabowo Chef'),
(173, 'laki-laki', 'Chica Craft'),
(174, 'Perempuan ', 'Voilaya Hijab'),
(175, 'Perempuan ', 'Feed Mee'),
(176, 'Perempuan ', 'D\'Nining');

-- --------------------------------------------------------

--
-- Table structure for table `jumlah_umkm`
--

CREATE TABLE `jumlah_umkm` (
  `id` int(11) NOT NULL,
  `no_urut` int(11) DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `nama_usaha` varchar(255) DEFAULT NULL,
  `nama_pelaku_usaha` varchar(255) DEFAULT NULL,
  `jenis_kelamin` varchar(255) DEFAULT NULL,
  `nik` varchar(64) DEFAULT NULL,
  `kk` varchar(64) DEFAULT NULL,
  `alamat_sesuai_ktp` text DEFAULT NULL,
  `kelurahan` varchar(255) DEFAULT NULL,
  `kecamatan` varchar(255) DEFAULT NULL,
  `alamat_domisili` text DEFAULT NULL,
  `alamat_tempat_usaha` text DEFAULT NULL,
  `no_telp` varchar(64) DEFAULT NULL,
  `status_pengelolaan_usaha` varchar(255) DEFAULT NULL,
  `legalitas_yang_dimiliki` varchar(255) DEFAULT NULL,
  `nomor_legalitas` varchar(64) DEFAULT NULL,
  `sektor_usaha` varchar(255) DEFAULT NULL,
  `jenis_produk` text DEFAULT NULL,
  `nama_produk_merk` varchar(255) DEFAULT NULL,
  `kelas_merek` varchar(255) DEFAULT NULL,
  `jumlah_tenaga_kerja` int(11) DEFAULT NULL,
  `omset_per_bulan` varchar(255) DEFAULT NULL,
  `no_pendaftaran` varchar(64) DEFAULT NULL,
  `status_pendaftaran` varchar(255) DEFAULT NULL,
  `realisasi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jumlah_umkm`
--

INSERT INTO `jumlah_umkm` (`id`, `no_urut`, `no`, `nama_usaha`, `nama_pelaku_usaha`, `jenis_kelamin`, `nik`, `kk`, `alamat_sesuai_ktp`, `kelurahan`, `kecamatan`, `alamat_domisili`, `alamat_tempat_usaha`, `no_telp`, `status_pengelolaan_usaha`, `legalitas_yang_dimiliki`, `nomor_legalitas`, `sektor_usaha`, `jenis_produk`, `nama_produk_merk`, `kelas_merek`, `jumlah_tenaga_kerja`, `omset_per_bulan`, `no_pendaftaran`, `status_pendaftaran`, `realisasi`) VALUES
(1, 1, 263, 'Kedai Jajanan\'s Bu Thiwuk 808 ', 'Sunarti', 'PEREMPUAN', '3578064804600004', '3578060501082769', 'Patemon 3/66', 'Patemon', 'Sawahan', 'Patemon 3/66', 'Patemon 3/66', '85777845351', 'PERSEORANGAN', 'NIB ', '708230055435', 'Makanan', 'Kue Basah : Lemper, Nagasari, Risoles, Kue Kentang', 'Kedai Jajanan\'s Bu Thiwuk 808 ', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(2, 2, 264, 'tumbas jajan', 'Jella Rosa Ayu Jenika', 'PEREMPUAN', '357065106950001', '3578062811190006', 'Kedung Anyar 1/26-D RT 002 RW 012', 'Sawahan', 'Sawahan', 'Kedung Anyar 1/26-D RT 002 RW 012', 'Kedung Anyar 1/26-D RT 002 RW 012', '82229222055', 'PERSEORANGAN', 'NIB ', '2309220038254', 'Makanan', 'roti dan kueh', 'tumbas jajan', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(3, 3, 265, 'KSM Familiy', 'Sri Utari', 'PEREMPUAN', '3578066611730010', '3578060101080931', 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Banyu Urip Lor 10/68 RT 004 RW 006', '81223419108', 'PERSEORANGAN', 'NIB ', '1808220023973', 'Makanan', 'makanan catering', 'KSM Familiy', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(4, 4, 266, 'Dapur Mamabi', 'Andi Defi Trianti', 'PEREMPUAN', '3578066604820010', '3578060101083231', 'Haimun 14-A RT 001 RW 008', 'Sawahan', 'Sawahan', 'Haimun 14-A RT 001 RW 008', 'Haimun 14-A RT 001 RW 008', '81336442386', 'PERSEORANGAN', 'NIB ', '2203220044429', 'Makanan', 'Rujak cingur, Nasi daging sapi, nasi campur', 'Dapur Mamabi', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(5, 5, 262, 'Mentoel sawahan', 'Asmariani', 'PEREMPUAN', '3578064403680003', '3578060101082296', 'Wonokitri 2/123 RT 004 RW 001', 'Pakis ', 'Sawahan', 'Wonokitri 2/123 RT 004 RW 001', 'Wonokitri 2/123 RT 004 RW 001', '895321348181', 'PERSEORANGAN', 'NIB ', '903230069325', 'Makanan', 'Kue sus, kue lapis, risoles mayones (kue basah), kue kacang (kue kering)', 'Mentoel sawahan', '30', 1, 'Rp2.500.000,00', NULL, NULL, 'NOPEMBER'),
(6, 6, 268, 'bundaweny 16', 'weny indri hapsari', 'PEREMPUAN', '3578065009790001', '3578060201080318', 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Sawahan', 'Sawahan', 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Kedung Anyar 9/16 RT 008 RW 003  ', '81315531522', 'PERSEORANGAN', 'NIB ', '1403230045357', 'Makanan', 'Roti, kueh', 'bundaweny 16', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(7, 7, 269, 'Mie Ayam Pangsit Sidomulyo', 'Yeni Kustiah', 'PEREMPUAN', '3517056602900001', '3578062310170006', 'Simo Sidomulyo GG 4 No14', 'Petemon', 'Sawahan', 'Simo Sidomulyo GG 4 No14', 'Simo Sidomulyo GG 4 No14', '82331641822', 'PERSEORANGAN', 'NIB ', '312220006294', 'Makanan', 'Mie Ayam', 'Mie Ayam Pangsit Sidomulyo', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(8, 8, 270, 'Papin Foods And Drinks', 'Afia Khoiriza', 'PEREMPUAN', '3578064410730005', '3578060101088923', 'Simo Sidomulyo I/12A', 'Petemon', 'Sawahan', 'Simo Sidomulyo I/12A', 'Jalan Petemon III No.35B', '82142944593', 'PERSEORANGAN', 'NIB ', '2203220046218', 'Makanan', 'Mie Kotak, Nasi Telur Balado, Nasi Telur kecap, nasi krengsengan daging sapi', 'Papin Foods And Drinks', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(9, 9, 271, 'RR21', 'Hartatik', 'PEREMPUAN', '5271025801780001', '3578062610200009', 'Kembang Kuning Kramat 2/21-A', 'Pakis ', 'Sawahan', 'Kembang Kuning Kramat 2/21-A', 'Kembang Kuning Kramat 2/21-A', '859555141899', 'PERSEORANGAN', 'NIB ', '2706230055764', 'Makanan Minuman', 'Es Dawet, Es Campur, Es Cincau, Es Buah Jadul (air yang dibekukan), Keripik Laderan (keripik yang ditipiskan)', 'RR21', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(10, 10, 272, 'Bu Ncik', 'Sri Mulyati', 'PEREMPUAN', '3213126101780001', ' ', 'Dukuh Kupang Timur VI/3', 'Pakis ', 'Sawahan', 'Dukuh Kupang Timur VI/3', 'Dukuh Kupang Timur VI/3', '85334730967', 'PERSEORANGAN', 'NIB ', '1909210012057', 'Makanan', 'Siomay dan Batagor (Baso Tahu Goreng)', 'Bu Ncik', '29', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(11, 11, 273, 'Omah Klemben', 'Francisca Mimosa', 'PEREMPUAN', '3578066403750002', '3578062505220010', 'Pakis Tirtosari 10/9', 'Pakis ', 'Sawahan', 'Pakis Tirtosari 10/9', 'Pakis Tirtosari 10/9', '81358086683', 'PERSEORANGAN', 'NIB ', '411240065549', 'Makanan', 'Kue Pangsit China ( siomay campuran daging ayam dan udang), sambal bawang', 'Omah Klemben', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(12, 12, 274, 'DNCook', 'Pudjiati', 'PEREMPUAN', '3578066908860012', '3578060101089777', 'Banyu Urip Jaya 6/54', 'Putat Jaya', 'Sawahan', 'Banyu Urip Jaya 6/54', 'Banyu Urip Jaya 6/54', '081231377186', 'PERSEORANGAN', 'NIB ', '1312220057549', 'mAKANAN', 'nASI kOTAK, nASI tumpeng', 'DNCook', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(13, 13, 275, 'Dapur Yang Ti', 'Suherman', 'Laki Laki', '3578060606600009', '3578060501080592', 'Jl. Petemon 4 No.93', 'Petemon', 'Sawahan', 'Petemon 4 No.93', 'Petemon 4 No.93', '082142215909', 'PERSEORANGAN', 'NIB ', '2804240003145', 'Makanan', 'Nasi Kotak, Nasi Kuning, Nasi Campur, Nasi Ayam', 'Dapur Yang Ti', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(14, 14, 276, 'Fiza Collection', 'Irsyadyyah', 'PEREMPUAN', '3578065304950003', '2310240249862', 'Kedung Anyar 8/54-B', 'sawahan', 'sawahan', 'Kedung Anyar 8/54-B', 'Kedung Anyar 8/54-B', '089516499572', 'PERSEORANGAN', 'NIB ', '2310240249862', 'Fashion/Handicratf', 'Baju daur ulang, bucket bunga', NULL, '16', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(15, 15, 277, 'BDS(Bakoel Duren Soerabaja)', 'Emi Kusumandari', 'PEREMPUAN', '3578066205660004', '35780422031000221', 'Banyu Urip Kidul 2a/11', 'banyu urip', 'sawahan', 'Banyu Urip Kidul 2a/11', 'Banyu Urip Kidul 2a/11', '08817561929', 'PERSEORANGAN', 'NIB ', '2506240034058', 'Minuman', 'Ketan Durian , Esteler Durian', 'BDS(Bakoel Durian Soeranajan)', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(16, 16, 278, 'Pari\'e Qu', 'Mariningsih', 'PEREMPUAN', '3578066111740007', '3578010201089945', 'Petemon 4/132a', 'petemon', 'sawahan', 'Petemon 4/132a', 'Petemon 4/132a', '081230333352', 'PERSEORANGAN', 'NIB ', '3005220036117', 'Makanan', 'Risoles, Pastel isi daging dan sayuran , bubur sagu mutiara', 'Pari\'e Qu', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(17, 17, 279, 'Kenari\'s KUKER', 'Kurniawati', 'PEREMPUAN', '3578064402820008', '3578060201080655', 'Banyurip wetan4/32', 'banyu urip', 'sawahan', 'Banyurip wetan4/32', 'Banyurip wetan4/32', '085748692784', 'PERSEORANGAN', 'NIB ', '1512210025567', 'Makanan', 'kue coklat almond, kue Nastar, kastengel', 'KENARI;S KUKER', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(18, 18, NULL, 'Bun\'s Craft', 'Sulistiyowati', 'PEREMPUAN', '3578066308720001', '3578060601088829', 'Kupang Gunung Jaya 3/29', 'Putat Jaya', 'sawahan', 'Kupang Gunung Jaya 3/29', 'Kupang Gunung Jaya 3/29', '082141146564', 'PERSEORANGAN', 'NIB ', '0202230065816', 'Kerajinan', 'Kotak Tisu, Tas, Aksesories, ', 'Bun\'s Craft', '20', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(19, 19, NULL, 'Dapoerbundhae99', 'Winarti', 'PEREMPUAN', '3578064208750004', '3578060101085936', 'Simo Gunung Kramat Selatan 2', 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Selatan 2', 'Simo Gunung Kramat Selatan 2', '085757538321', 'PERSEORANGAN', 'NIB ', '2607220050686', 'Makanan', 'Nasi Kotak, Nasi Tumpeng', 'Dapoerbundhae99', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(20, 20, NULL, 'Obiesh Cake', 'Sulis Setyowati', 'PEREMPUAN', '3578065012860002', '3578061706220004', 'Banyu Urip Kidul 5/59', 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 5/59', 'Banyu Urip Kidul 5/59', '085850750563', 'PERSEORANGAN', 'NIB ', '0808230067061', 'Makanan', 'Roti , Kue Brownies, Kue Bolen, Kue Donat', 'Obiesh Cake', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(21, 21, NULL, 'Nombusi', 'Susilowati', 'PEREMPUAN', '3578066601770006', '3578060501086374', 'Banyu Urip Lor 2/18', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 2/18', 'Banyu Urip Lor 2/18', '082140992407', 'PERSEORANGAN', 'NIB ', '2310240263832', 'Minuman', 'Kunyit asem, Beras kencur', 'Nombusi', '5', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(22, 22, NULL, 'Sarisol', 'Sari Mawardhany', 'PEREMPUAN', '3578064811730006', '3578060101082758', 'Banyu Urip Kidul 6G/8', 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 6G/8', 'Banyu Urip Kidul 6G/8', '083830191515', 'PERSEORANGAN', 'NIB ', '0608240048272', 'makanan', 'risoles.', 'Sarisol', '30', 1, 'Rp. 2.000.000,-', NULL, NULL, NULL),
(23, 23, NULL, 'Svedanika', 'Ernawati', 'PEREMPUAN', '3578065104760007', '3578060101081506', 'Petemon 2/104-A', 'petemon', 'Sawahan', 'Petemon 2/104-A', 'Petemon 2/104-A', '085606606655', 'PERSEORANGAN', 'NIB ', '2607220058349', 'Makanan', 'Kue Basah,  Donar, Risoles', 'Svedanika', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(24, 24, NULL, '3 Putra 5758', 'Kukuh Prasetyo', 'Laki Laki', '3575021702820003', '3578060801200011', 'Putat Jaya C Timur III/15', 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur III/15', 'Putat Jaya C Timur III/15', '\'081952772274', 'PERSEORANGAN', 'NIB ', '2311230080228', 'Makanan', 'Roti, Kue, Kembang Gula', '3 Putra 5758', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(25, 25, NULL, 'Lilos\'s', 'Alvi Maghfiratul Laila', 'PEREMPUAN', '357317010710004', '3578312910220002', 'Queens Town Q I/57', 'sambikerep', 'sambikerep', 'Queens Town Q I/57', 'Queens Town Q I/57', '08113355772', 'PERSEORANGAN', 'NIB ', '2206220093782', 'Fashion', 'Pakaian Wanita', 'Lilos\'s', '25', 2, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(26, 26, NULL, 'Kedai Jajan caraki', 'Anggita Kenangsary', 'PEREMPUAN', '3578064107820010', '3578062301200109', 'Wonokitri 2 No.116', 'Pakis ', 'Sawahan', 'Wonokitri 2 No.116', 'Wonokitri 2 No.116', '081230786483', 'PERSEORANGAN', 'NIB ', '2709230079718', 'Makmin', 'Kue kering/kue basah', 'Kedai Jajan caraki', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(27, 27, NULL, 'D\'rezluck', 'Siti Nurmilah', 'PEREMPUAN', '3578144909900001', '3578142709190002', 'Balongsari Blok 4-G/5', 'Balongsari', 'Tandes', 'Balongsari Blok 4-G/5', 'Balongsari Blok 4-G/5', '085959915912', 'PERSEORANGAN', 'NIB ', '1208240037491', 'Kerajinan', 'Rajutan', 'D\'rezluck', '23', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(28, 28, NULL, 'Heru Fish Waffle', 'Heru Dharmawan', 'Laki Laki', '3578061602820007', '3578062407200004', 'Simo Gunung Kramat Timur 1/30', 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Timur 1/30', 'Simo Gunung Kramat Timur 1/30', '081333243466', 'PERSEORANGAN', 'NIB ', '0901240063935', 'Makanan', 'Waffel', 'Heru Fish Waffle', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(29, 29, NULL, 'GLORIA88', 'Rendra Chrismatofan', 'Laki Laki', '\'3578061802840007', '3578062611090014', 'Dukuh pakis 6D1-B No.3', 'Pakis ', 'Sawahan', 'Dukuh pakis 6D1-B No.3', 'Dukuh pakis 6D1-B No.3', '081234857424', 'PERSEORANGAN', 'NIB ', '1403230056855', 'Makanan', 'Mie Ayam', 'GLORIA88', '43', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(30, 30, NULL, 'Warunguntur 77', 'Soemiyati', 'PEREMPUAN', '3578064303590008', '3578061904170003', 'Kranggang Pangselan 5/14 ', 'Sawahan', 'Sawahan', 'Kranggang Pangselan 5/14 ', 'Kranggang Pangselan 5/14 ', '082257776773', 'PERSEORANGAN', 'NIB ', '3578061904170003', 'Makanan', 'Nasi Campur', 'Warunguntur77', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(31, 31, NULL, 'Zafir Style', 'Anik Masturin', 'PEREMPUAN', '\'3578065810780001', '3578060601088774', 'Petemon 2/84 B ', 'Petemon', 'Sawahan', 'Petemon 2/84 B ', 'Petemon 2/84 B ', '081333275655', 'PERSEORANGAN', 'NIB ', '2911240052609', 'Fashion', 'Kemeja Pria, Jas Pria', 'Zafir Style', '25', 2, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(32, 32, NULL, 'Pastelikah', 'Setyono', 'Laki Laki', '3578060905750005', '3578060201081779', 'Banyu Urip Lor 6/88', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 6/88', 'Banyu Urip Lor 6/88', '087852755388', 'PERSEORANGAN', 'NIB ', '3012230205498', 'Makanan', 'Pastel mini', 'Pastelikah', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(33, 33, NULL, 'EMAK SIMO', 'Soepinianti', 'PEREMPUAN', '3578065802610001', '3578060601083848', 'Simo Gunung 1/20', 'Banyu urip', 'Sawahan', 'Simo Gunung 1/20', 'Simo Gunung 1/20', '083830003029', 'PERSEORANGAN', 'NIB ', '2203220044238', 'makanan', 'Nasi Ayam Kecap, Nasi semur dll', 'EMAK SIMO', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(34, 34, NULL, 'NONA\'S FOOD', 'Elisda Hariyanti', 'PEREMPUAN', '3525166507920001', '3578060408150007', 'Girilaya 2/31', 'Banyu urip', 'Sawahan', 'Girilaya 2/31', 'Girilaya 2/31', '082139230529', 'PERSEORANGAN', 'NIB ', '2810240147594', 'Makanan', 'Ayam Geprek, Lumpiah Goreng', 'NONA\'S Food', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(35, 35, NULL, 'GENarta Collection', 'Silvia Ratnani', 'PEREMPUAN', '3525044103920001', '3578060704170008', 'Putat Jaya C Timur 3/3', 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur 3/3', 'Putat Jaya C Timur 3/3', '081357822559', 'PERSEORANGAN', 'NIB ', '2002220023085', 'Kerajinan', 'Flanel, Bucket', 'GENarta Collection', '16', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(36, 36, NULL, 'Sambal Bu Fatimah', 'Siti Fatimah', 'PEREMPUAN', '3578064608750001', '\'3578060101088372', 'Simo Gunung Baru Jaya Blok G1/10', 'Putat Jaya', 'Sawahan', 'Simo Gunung Baru Jaya Blok G1/10', 'Simo Gunung Baru Jaya Blok G1/10', '081235652676', 'PERSEORANGAN', 'NIB ', '2203220043487', 'Makanan', 'Ayam Geprek, Penyet', 'Sambal Bu Fatimah ', '29', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(37, 37, NULL, 'Oemah Daharan', 'Rosyta Aisyaroh Rahmawati P', 'PEREMPUAN', '3578064306950004', '\'3578060601220004', 'Kupang Gunung Timur 7vB/45', 'Putat Jaya', 'Sawahan', 'Kupang Gunung Timur 7 -B/45', 'Kupang Gunung Timur 7 -B/45', '087855549981', 'PERSEORANGAN', 'NIB ', '2005240040881', 'Makanan', 'Kue Pangsit Cina\' Nasi Ayam Geprek', 'Oemah Daharan', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(38, 38, NULL, 'Mimi cakecookies', 'Surochmah', 'PEREMPUAN', '3578066406770001', '3578060201080217', 'Kembang Kuning Mulyo I No.4', 'Pakis ', 'Sawahan', 'Kembang Kuning Mulyo I No.4', 'Kembang Kuning Mulyo I No.4', '082233352380', 'PERSEORANGAN', 'NIB ', '2506220025719', 'Makanan', 'Kue Pai, Nastar, Kastangel, Semprit, Keju dll', 'Mimicakecookies', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(39, 39, NULL, 'Wastra Bag', 'Adhela Mahaswari Pikantara D', 'PEREMPUAN', '3578036107010008', '3578030101081697', 'Rungkut Kidul Lor RL 2C/29 ', 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '082131345066', 'PERSEORANGAN', 'NIB ', '0409240025273', 'Fashion', 'Tas, Dompet', 'Wastra Bag', '18', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(40, 40, NULL, 'Ellegant Batik', 'Nurul Ziana', 'PEREMPUAN', '3578035606680002', '3578030101081697', 'Rungkut Kidul Lor RL 2C/29 ', 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '081334512300/0813315151', 'PERSEORANGAN', 'NIB ', '1295000603609', 'Fashion', 'Baju', 'Ellegant Batik', '25', 1, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(41, 41, NULL, 'Lieng Ows Tee', 'Indah Surjani Goeyardi', 'PEREMPUAN', '3578066409760007', '3578021101190001', 'Bendulmerisi Selatan 3/15', 'Bendulmerisi ', 'wonocolo', 'Bendulmerisi Selatan 3/15', 'Bendulmerisi Selatan 3/15', '0821151111368', 'PERSEORANGAN', 'NIB ', '1908240076005', 'Kerajinan', 'Boneka Rajut', 'Lieng Ows Tee', '23', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(42, 42, NULL, 'Benyamin Yacob', 'Raditya Pratama Juwiandinanta', 'Laki Laki', '3978180705060001', '3578180101084243', 'Lakarsantri RT 2 RW 4', 'Lakarsantri', 'Lakarsantri', 'Lakarsantri RT 2 RW 4', 'Lakarsantri RT 2 RW 4', '081336956366', 'PERSEORANGAN', 'NIB ', '0302250042994', 'Fashion', 'Busana', 'Benyamin Yacob', '25', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(43, 43, NULL, 'Mai Co Tailor', 'Natasya Cornelia', 'PEREMPUAN', '3578206603010002', '3578200101083458', 'Royal Park 2 Blok TK 3-78', 'Lidah kulon', 'Lakarsantri', 'Royal Park 2 Blok TK 3-78', 'Royal Park 2 Blok TK 3-78', '081213819006', 'PERSEORANGAN', 'NIB ', '2210240275722', 'Fashion', 'Pakaian .', 'Mai Co Tailor', '5', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(44, 44, NULL, 'ZARARA BAKERY', 'Arie Wardiani SPd', 'PEREMPUAN', '3578076601750001', '\'3578302206190001', 'Griya Benowo Indah Blok C/7', 'Babat Jerawat ', 'Pakal', 'Griya Benowo Indah Blok C/7', 'Griya Benowo Indah Blok C/7', '087829722378', 'PERSEORANGAN', 'NIB ', '1407240028975', 'Makanan', 'Roti', 'ZARARA BAKERY', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(45, 45, NULL, 'La Tea Es Teh jumbo', 'Lailatul Nuzul', 'PEREMPUAN', '3578046310720003', '3578046310720003', 'Ngagel Mulyo 16/65 B', 'Ngegel Rejo', 'Wonokromo', 'Ngagel Mulyo 16/65 B', 'Ngagel Mulyo 16/65 B', '082331445600', 'PERSEORANGAN', 'NIB ', '0508230021492', 'Minnuman', 'Es Teh', 'LA Tea Es Teh Jumbo', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(46, 46, NULL, 'Cahaya Baru', 'Julius Alvaro Sumargo', 'Laki Laki', '3509060907050002', '3578082410190002', 'Mojoarum 2/6', 'Mojo ', 'Gubeng', 'Mojoarum 2/6', 'Mojoarum 2/6', '0895620107573', 'PERSEORANGAN', 'NIB ', '1202250100852', 'Makanan', 'Ayam goreng, ', 'Resep Makmuk', '29', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(47, 47, NULL, 'Dina Collection', 'Agust Nurdiana', 'PEREMPUAN', '3374025008750003', '3578150505150007', 'Kemayoran Masjid No.4', 'Krembangan Selatan ', 'Krembangan', 'Kemayoran Masjid No.4', 'Kemayoran Masjid No.4', '088226368757', 'PERSEORANGAN', 'NIB ', '3105220013326', 'Fashion ', 'Kain Ecoprint', 'K\'Din', '24', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(48, 48, NULL, 'Sastarasa Sebuah Karya rasa', 'Nurullina Puspasari', 'PEREMPUAN', '3578065503660006', '3578060401082085', 'Pakis Wetan 5/92A', 'Pakis ', 'Sawahan', 'Pakis Wetan 5/92A', 'Pakis Wetan 5/92A', '082142773005', 'PERSEORANGAN', 'NIB ', '0411240092641', 'Makanan', 'Soto Banjar', 'Sastrarasa sebuah karya rasa', '29', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(49, 49, NULL, 'Treepuspa', 'Tria Agustin Nugrahini , SE', 'PEREMPUAN', '3578076208740001', '3578070101082490', 'Pogot Baru GG Karya Bakti No 12', 'Tanah Kali kedinding', 'Kenjeran', 'Pogot Baru GG Karya Bakti No 12', 'Pogot Baru GG Karya Bakti No 12', '087854446874', 'PERSEORANGAN', 'NIB ', '0268010140133', 'Fashion', 'Tas Wanita', 'Treepuspa', '16', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(50, 50, NULL, 'Griya Gemati ', 'Arief Budiman ', 'Laki Laki', '3578202704700003', '3578200308090004', 'Babatan Pratama Blok HH - 7 ', 'Babatan ', 'Wiyung ', 'Babatan Pratama Blok HH - 7 ', 'Babatan Pratama Blok HH - 7 ', '08155116119', 'PERSEORANGAN', 'NIB ', '1810220244225', 'Fashion', 'Kain Batik ', 'Griya Gemati ', '24', 2, 'Rp5.000.000,00', NULL, NULL, NULL),
(51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(52, 51, NULL, 'Ben\'e-E Drink', 'Wahjudi Utomo MDRS Ak', 'Laki Laki', '3578041505660010', '3578020201082960', 'Bendul merisi No.134', 'sidosermo', 'wonocolo', 'Bendul merisi No.134', 'Bendul merisi No.134', '081315380790', 'PERSEORANGAN', 'NIB ', '1202220016167', 'Minuman', 'minuman rasa buah, sirup untuk membuat minuman rasa buah, Sari buah, Jus sari buah-buahan', 'Ben\'e-E Drink', '32', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(53, 52, NULL, 'Bandengku Bandeng Presto Bendul', 'Supaekan Siswanto', 'Laki Laki', '3578040401700010', '3578020101080989', 'Bendul Merisi Besar Sel 47 F', 'Bendul merisi ', 'Wonocolo', 'Bendur Merisi Besar Sel 47 F', 'Bendur Merisi Besar Sel 47 F', '082337870972', 'PERSEORANGAN', 'NIB ', '2812220021478', 'Makanan', 'hasil olahan ikan untuk makanan manusia', 'Bandengku Bandeng Presto Bendul Merisi', '29', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(54, 53, NULL, 'Radjamoe', 'Dyah Wahyu  Pratiwi', 'PEREMPUAN', '3578024505700003', '3578020201088780', 'Siswalankerto 27B', 'siwalankerto', 'Wonocolo', 'Siswalankerto 27B', 'Siswalankerto 27B', '082230769726', 'PERSEORANGAN', 'NIB ', '2611210010918', 'Minuman', 'minuman rasa buah, sirup untuk membuat minuman rasa buah, Sari buah, Jus sari buah-buahan', 'Radjamoe', '32', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(55, 54, NULL, 'Glant & Co', 'Sri Hartatik', 'PEREMPUAN', '3578136106780002', '357813101220002', 'Asem Bagus II/17-A', 'Tembok Dukuh', 'Bubutan', 'Asem Bagus II/17-A', 'Asem Bagus II/17-A', '081331488441', 'PERSEORANGAN', 'NIB ', '1209000700736', 'Fashion', 'Pakaian', 'Rutz', '25', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(56, 55, NULL, 'Roti Bakar BRO-SIS ', 'Hardini Vika Titasari', 'Perempuan', '3578055501970001', '3578050101086258', 'Wonorejo 3/72 RT 004 RW 005 ', 'Wonorejo', 'Tegalsari ', 'Wonorejo 3/72 RT 004 RW 005 ', 'Wonorejo 3/72 RT 004 RW 005 ', '082257668188', 'PERSEORANGAN', 'NIB ', '0810240120904', 'Makanan ', 'Bahan makanan untuk adonan roti dan kue, adonan roti, roti pastry, roti tawar manis, roti dan roti bun, makanan ringan terutama terdiri dari roti, roti asin, roti bakar ', 'ROTI BAKAR BRO-SIS ', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(57, 56, NULL, 'HEY Cincau!', 'Nandjar Wiludjeng', 'Perempuan', '3578225604850001', '3578221402130004', 'Gayungsari Barat 09/17 RT 003 RW 007 ', 'Gayungan ', 'Gayungan ', 'Gayungsari Barat 09/17 RT 003 RW 007 ', 'Gayungsari Barat 09/17 RT 003 RW 007 ', '082141560201', 'Perseorangan ', 'NIB ', '2212210016146', 'Makanan ', 'minuman cincau, jus lemon [minuman], jus lemon untuk digunakan dalam persiapan minuman, jus jeruk nipis untuk digunakan dalam persiapan minuman', 'HEY Cincau!', '32', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(58, 57, NULL, 'WIL', 'Endi Putranto ', 'Laki Laki', '3578280809910001', '3578282202210001', 'Tambak dalam Baru 3 No 27 RT 003 RW 005 ', 'Asemrowo ', 'Asemrowo', 'Tambak dalam Baru 3 No 27 RT 003 RW 005 ', 'Tambak dalam Baru 3 No 27 RT 003 RW 005 ', '085102242289', 'Perseorangan ', 'NIB ', '0102240035565', 'Fashion ', 'Parfum', 'WIL ', '3', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(59, 58, NULL, 'Memoire Haus ', 'Anastasia Marin Purnama ', 'Perempuan', '3578095706960001', '3578090307130009', 'Nginden Intan Utara No 48 RT 001 RW 009 ', 'Nginden Jangkungan ', 'Sukolilo ', 'Nginden Intan Utara No 48 RT 001 RW 009 ', 'Nginden Intan Utara No 48 RT 001 RW 009 ', '08113545227', 'Perseorangan ', 'NIB ', '0303250043491', 'Lain lain ', 'Selimut Tidur ', 'Memoire Haus ', '24', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(60, 59, NULL, 'Auf Beauty ', 'Tria Gustina Setiani, S.Psi ', 'Perempuan ', '3578234508790002', '3578230101085038', 'Perum Puri Kencana Karah B-19 RT 005 RW 011', 'Karah ', 'Jambangan ', 'Perum Puri Kencana Karah B-19 RT 005 RW 011', 'Perum Puri Kencana Karah B-19 RT 005 RW 011', '08123251029', 'Perseorangan ', 'NIB ', '2012230034067', 'Kosmetik ', 'Sabun dan Sediaan aromaterapi', 'Auf Beauty ', '3', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(61, 60, NULL, 'Cendol With You ', 'Anny Setyorini, SE ', 'Perempuan ', '3578235804740002', '3578232803110004', 'Jl Pagesangan IIIA/81 RT 004 RW 003 ', 'Pagesangan ', 'Jambangan ', 'Jl Pagesangan IIIA/81 RT 004 RW 003 ', 'Jl Pagesangan IIIA/81 RT 004 RW 003 ', '0895429763355', 'Perseorangan ', 'NIB ', '2105230021268', 'Minuman ', 'Minuman Dawet ', 'Cendol With You ', '32', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(62, 61, NULL, 'Kaudhawa Tea ', 'Alfan Bramestia', 'Laki Laki', '3578232103860002', '3578231402110011', 'Kebonsari Gg 5/7 - L RT 006 RW 002 ', 'Kebonsari ', 'Jambangan ', 'Kebonsari Gg 5/7 - L RT 006 RW 002 ', 'Kebonsari Gg 5/7 - L RT 006 RW 002 ', '081234468480', 'Perseorangan ', 'NIB ', '1205240054213', 'Minuman', 'Minuman Teh ', 'KAUDHAWA TEA ', '30', 1, 'Rp6.000.000,00', NULL, NULL, NULL),
(63, 62, NULL, 'Zane ', 'Novia Fadhilah Zain ', 'Perempuan ', '3578266411970001', '3578261703210009', 'Manyar sabrangan 6A/12 RT 002 RW 002', 'Manyar Sabrangan ', 'Mulyorejo ', 'Manyar sabrangan 6A/12 RT 002 RW 002', 'Manyar sabrangan 6A/12 RT 002 RW 002', '081249716911', 'Perseorangan ', 'NIB ', '2505230054262', 'Fashion ', 'Perhiasan Kecil (Barang-barang perhiasan) ', 'Zane ', '14', 1, 'Rp8.000.000,00', NULL, NULL, NULL),
(64, 63, NULL, 'Kopi Grobar ', 'Rudyk Hermawan ', 'Laki Laki', '3578270603900004', '3578181701180001', 'Simo Pomahan 3/27 RT 009 RW 002 ', 'Simomulyo Baru ', 'Sukomanunggal ', 'Simo Pomahan 3/27 RT 009 RW 002 ', 'Simo Pomahan 3/27 RT 009 RW 002 ', '082142043600', 'Perseorangan ', 'NIB ', '0510230031616', 'Minuman ', 'Minuman Kopi , Minuman Teh', 'Kopi Grobar ', '30', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(65, 64, NULL, 'Dapur Mak R.A ', 'Trisia Indra Sarie ', 'Perempuan ', '3515136101820006', '3578042305130003', 'Gajah Mada Baru 1/139 RT 009 RW 012 ', 'Sawunggaling ', 'Wonokromo ', 'Gajah Mada Baru 1/139 RT 009 RW 012 ', 'Gajah Mada Baru 1/139 RT 009 RW 012 ', '081235755770', 'Perseorangan ', 'NIB ', '1295000620676', 'Makanan', 'Roti, Kue Kering, Nasi Kotak, Kue Basah ', 'Dapur Mak R.A', '30', 1, 'Rp7.500.000,00', NULL, NULL, NULL),
(66, 65, NULL, 'Rayu Manis ', 'Citra Purba Erwina, ST ', 'Perempuan ', '3578026001820002', '3578020101087331', 'Sidosermo Indah No 23 RT 001 RW 006 ', 'sidosermo', 'Wonocolo', 'Sidosermo Indah No 23 RT 001 RW 006 ', 'Sidosermo Indah No 23 RT 001 RW 006 ', '081231177447', 'Perseorangan ', 'NIB ', '1274000602289', 'Makanan', 'Roti dan Kue ', 'Rayu Manis ', '30', 1, 'Rp7.000.000,00', NULL, NULL, NULL),
(67, 66, NULL, 'Dapur Budhe Dreamland ', 'Ririn Pujiati ', 'Perempuan ', '3578064507760009', '3578191108170004', 'Perum Dreaming Land Blok D 6/10 RT 009 RW 004', 'Sememi ', 'Benowo ', 'Perum Dreaming Land Blok D 6/10 RT 009 RW 004', 'Perum Dreaming Land Blok D 6/10 RT 009 RW 004', '087747778568', 'Perseorangan ', 'NIB ', '0610220031616', 'Makanan ', 'Kue Basah, Nasi Kotak , Nasi Ayam ', 'Dapur Budhe Dreamland ', '30', 1, 'Rp8.000.000,00', NULL, NULL, NULL),
(68, 67, NULL, 'Dreamingland Snacks', 'Suprihayu Prinaryanti ', 'Perempuan ', '3572035301840006', '3578192801130003', 'Perum Dreaming Land Blok D3/9 RT 001 RW 010 ', 'Sememi ', 'Benowo ', 'Perum Dreaming Land Blok D3/9 RT 001 RW 010 ', 'Perum Dreaming Land Blok D3/9 RT 001 RW 010 ', '081252843750', 'Perseorangan ', 'NIB ', '1602230031353', 'Makanan ', 'Sate Jamur, kacang olahan, olahan makanan terutama terdiri dari produk daging, 	Masakan olahan ayam yang dilapis atau dicampur dengan tepung, Makanan berbahan dasar tahu ', 'Dreamingland Snack ', '29', 1, 'Rp10.000.000,00', NULL, NULL, NULL),
(69, 68, NULL, 'Sri Wijaya 46 ', 'Sridiningsih ', 'Perempuan ', '3578196811760001', '3578190101083334', ' ', 'Sememi ', 'Benowo ', 'Sememi Jaya 4/6 RT 003 RW 001 ', 'Sememi Jaya 4/6 RT 003 RW 001 ', '081234668274', 'Perseorangan ', 'NIB ', '1210210036845', 'Makanan ', 'Kue Basah, Kue kering, makanan berbahan dasar tepung, brownies kukus, lemper, onde onde ketawa, risol, pastel berisi daging dan sayuran, kue sus, nasi campur, nasi kuning, nasi urap, nasi rames ', 'Sri Wijaya 46', '30', 1, 'Rp9.000.000,00', NULL, NULL, NULL),
(70, 69, NULL, 'DJP Dapuer Dwi JP ', 'Dwi Astutik ', 'Perempuan ', '3578155906790002', '3578150101085793', 'Dreaming Land D6 No 2 RT 001 RW 010 ', 'Sememi ', 'Benowo ', 'Dreaming Land D6 No 2 RT 001 RW 010 ', 'Dreaming Land D6 No 2 RT 001 RW 010 ', '083833584130', 'Perseorangan ', 'NIB ', '2402220020933', 'Makanan ', 'Nasi Campur, nasi ayam geprek, nasi kuning, kue kering, kue basah, Kue talam', 'DJP Dapuer Dwi JP ', '30', 1, 'Rp7.500.000,00', NULL, NULL, NULL),
(71, 70, NULL, 'Dapur Mak Uniek ', 'Uniek Rinawati ', 'Perempuan ', '3578304806700002', '3578303105120004', 'Pondok Benowo Indah Blok AD/10 RT 001 RW 006 ', 'Babat Jerawat ', 'Pakal ', 'Pondok Benowo Indah Blok AD/10 RT 001 RW 006 ', 'Pondok Benowo Indah Blok AD/10 RT 001 RW 006 ', '08970890886', 'Perseorangan ', 'NIB ', '2105240091113', 'Makanan ', 'Gurame Bakar , Ayam Bakar ', 'Dapuer Mak Unik ', '29', 1, 'Rp8.000.000,00', NULL, NULL, NULL),
(72, 71, NULL, 'Siseru ', 'Rahmi Reiza Caesarina ', 'Perempuan ', '3514125003910003', NULL, 'Gubeng Kertajaya 5C/11 RT 004 RW 003 ', 'Airlangga ', 'Gubeng ', 'Gubeng Kertajaya 5C/11 RT 004 RW 003 ', 'Gubeng Kertajaya 5C/11 RT 004 RW 003 ', '087763335481', 'Perseorangan ', 'NIB ', '0909240088247', 'Lain lain ', 'Mainan Anak anak ', 'SISERU ', '28', 1, 'Rp9.500.000,00', NULL, NULL, NULL),
(73, 72, NULL, 'LABAIK PIZZA ', 'Nanik Silverasudarwati ', 'Perempuan ', '3578047005730002', '3578040101081876', 'Ngagel Rejo 3B/19 RT 007 RW 002 ', 'Ngagelrejo ', 'Wonokromo ', 'Ngagel Rejo 3B/19 RT 007 RW 002 ', 'Ngagel Rejo 3B/19 RT 007 RW 002 ', '085156888970', 'Perseorangan ', 'NIB ', '3105220047923', 'Makanan ', 'Pizza', 'Labaik Pizza ', '30', 1, 'Rp7.500.000,00', NULL, NULL, NULL),
(74, 73, NULL, 'RAYFAN ', 'Rini Mahmudah ', '0', '3578046307800004', '3578042001250004', 'Jagir Sidomukti 2/46 RT 002 RW 003 ', 'Jagir ', 'Wonokromo ', 'Jagir Sidomukti 2/46 RT 002 RW 003 ', 'Jagir Sidomukti 2/46 RT 002 RW 003 ', '081235402058', 'Perseorangan ', 'NIB ', '1292001421583', 'Makanan ', 'makanan ringan berbahan dasar daging, produk daging berupa burger [roti daging]', 'RAYFAN ', '29', 1, 'Rp3.500.000,00', NULL, NULL, NULL),
(75, 74, NULL, 'Bilgharo Kitchen ', 'Mira Kustiyah', 'Perempuan ', '3578045202730004', '3578042603200006', 'Gembili 2/23 RT 002 RW 007 ', 'Jagir ', 'Wonokromo ', 'Gembili 2/23 RT 002 RW 007 ', 'Gembili 2/23 RT 002 RW 007 ', '087761613469', 'Perseorangan ', 'NIB ', '1603220021124', 'Makanan ', 'Nasi Krengsengan Ayam, makanan berbahan dasar tepung (SEMPOL), puding', 'Bilgharo Kitchen ', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(76, 75, NULL, 'Dapur Icha', 'Solichah', 'Perempuan', '3578105809840007', '3578092311200008', 'Gebanglor No. 50 A', 'Gebang Putih ', 'Sukolilo ', 'Gebanglor No. 50 A', 'Gebanglor No. 50 A', '087761801988', 'Perseorangan ', 'NIB ', '1701230060489', 'Makanan', 'Kue basah, Kue lumpur, Kue onde, donat', 'Dapur Icha', '30', 1, 'Rp3.500.000,00', NULL, NULL, NULL),
(77, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(78, 76, NULL, 'sunduk\'an sate kiandra ', 'Tina Purwati ', 'Perempuan ', '3578174506840001', '3578171002120004', 'Tanah merah 4 Semanggi No 48A RT 015 RW 004 ', 'Tanah Kali Kedinding ', 'Kenjeran ', 'Tanah merah 4 Semanggi No 48A RT 015 RW 004 ', 'Tanah merah 4 Semanggi No 48A RT 015 RW 004 ', '08999372988', 'Perseorangan ', 'NIB ', '3110230136895', 'Makanan', 'sate [daging panggang yang ditusuk], sayap ayam, telur asin, telur ayam, telur bebek, telur bekicot untuk dimakan, telur beku, telur bitan, telur bubuk, telur cair, telur ikan, diolah, Telur puyuh, Telur Rebus, telur burung dan produk telur, terrine daging, terrine ayam, 	produk susu', 'Sunduk\'an sate Kiandra ', '29', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(79, 77, NULL, 'Mem Mem ', 'Samuel Herman N Matulessy ', 'Perempuan ', '3578140309730003', '3578140101081473', 'Manukan Krido Blok 4-l/10 RT 005 RW 006 ', 'Manukan Kulon ', 'Tandes ', 'Manukan Krido Blok 4-l/10 RT 005 RW 006 ', 'Manukan Krido Blok 4-l/10 RT 005 RW 006 ', '082233360045', 'Perseorangan ', 'NIB ', '2403250042039', 'Makanan ', 'Produk olahan daging sapi, pentol olahan daging', 'Mem Mem ', '29', 1, 'Rp5.500.000,00', NULL, NULL, NULL),
(80, 78, NULL, 'Dimsum Dom ', 'Dedy Purwanto ', 'Laki laki ', '3578303112870002', '3578042606200009', 'Brawijaya Kedurus 1/64 RT 004 RW 006 ', 'Sawunggaling ', 'Wonokromo ', 'Brawijaya Kedurus 1/64 RT 004 RW 006 ', 'Brawijaya Kedurus 1/64 RT 004 RW 006 ', '081336351679/ 081290071626', 'Perseorangan ', 'NIB ', '2012210022174', 'Makanan ', 'layanan kios makanan menjadi layanan untuk menyediakan makanan dan minuman, penyediaan makanan dan minuman, penyajian makanan dan minuman', 'DIMSUM DOM ', '43', 2, 'Rp15.000.000,00', NULL, NULL, NULL),
(81, 79, NULL, 'Juragan Kress& Sueger ', 'Haryo Bagus Prasmono ', 'Laki laki ', '3515131908860003', '3578040201180003', 'Lesti 71 RT 008 RW 007 ', 'Darmo ', 'Wonokromo ', 'Lesti 71 RT 008 RW 007 ', 'Lesti 71 RT 008 RW 007 ', '082230433827', 'Perseorangan ', 'NIB ', '2610220035503', 'Makanan ', 'buah dan sayuran yang dimasak, minuman berbahan dasar susu, makanan ringan berbahan dasar kedelai', 'JURAGAN Kress & Sueger', '29', 1, 'Rp7.500.000,00', NULL, NULL, NULL),
(82, 80, NULL, 'Kedai Bu Mega ', 'Maria Megawati ', 'Perempuan ', '3578175601650001', '3578170301082597', 'Bulak Banteng Wetang 6/36 RT 005 RW 008 ', 'Sidotopo wetan ', 'Kenjeran ', 'Bulak Banteng Wetang 6/36 RT 005 RW 008 ', 'Bulak Banteng Wetang 6/36 RT 005 RW 008 ', '08123530641', 'Perseorangan ', 'NIB ', '2905230024342', 'Minuman ', 'sediaan minuman kakao', 'Kedai Bu Mega ', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(83, 81, NULL, 'Kripik Singkong Mbak Ibad ', 'Badriyah Kamilah ', 'Perempuan ', '3578054801830002', '3578050707150008', 'Pandegiling 5/22 A RT 006 RW 007 ', 'Tegalsari ', 'Tegalsari ', 'Pandegiling 5/22 A RT 006 RW 007 ', 'Pandegiling 5/22 A RT 006 RW 007 ', '081916817409', 'Perseorangan ', 'NIB ', '1701250064341', 'Makanan ', '	keripik singkong', 'Keripik singkong Mbak Ibad ', '29', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(84, 82, NULL, 'Zumi', 'Monica Hartono ', 'Perempuan ', '3578076706990003', '3578070201081966', 'Jagalan IV/33 RT 004 RW 016', 'Peneleh ', 'Genteng ', 'Pakuwon indah, waterplace Tower A unit 1505 ', 'Pakuwon indah, waterplace Tower A unit 1505 ', '08113393663', 'Perseorangan ', 'NIB ', '0711240112163', 'Minuman ', 'minuman berbahan dasar susu, Yoghurt', 'ZUMI ', '29', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(85, 83, NULL, 'POY ', 'Catur Ayu Wulandari ', 'Perempuan ', '3578052303730003', '3578050401081697', 'Surabayan 4/20 RT 006 RW 002', 'Kedungdoro ', 'Tegalsari ', 'Surabayan 4/20 RT 006 RW 002', 'Surabayan 4/20 RT 006 RW 002', '0895805314395', 'Perseorangan ', 'NIB ', '1412210019558', 'Makanan ', 'kebab shish (daging), dimsum, daging sapi olahan, masakan matang yang terbuat dari daging sapi, ikan, ayam yang dimasak, dikeringkan, dibekukan, diawetkan, Masakan olahan ayam yang dilapis atau dicampur dengan tepung', 'POY ', '29', 1, 'Rp7.000.000,00', NULL, NULL, NULL),
(86, 84, NULL, 'Sweettlekid', 'Rohdian Syah ', 'Laki laki ', '3578150611910001', '3578152212220011', 'Tambak Asri Putri Malu No 24 RT 010 RW 006 ', 'Morokrembangan ', 'Krembangan ', 'Tambak Asri Putri Malu No 24 RT 010 RW 006 ', 'Tambak Asri Putri Malu No 24 RT 010 RW 006 ', '081216711561', 'Perseorangan ', 'NIB ', '1302250107492', 'Fashion ', 'pakaian luar untuk anak laki-laki, pakaian luar untuk anak perempuan ', 'Sweettlekid', '25', 4, 'Rp15.000.000,00', NULL, NULL, NULL),
(87, 85, NULL, 'Bida 2 Bakery ', 'Dwi Sriana Juda Astuti', 'Perempuan ', '3515136005710002', '3578102003240038', 'Ploso 7/9 RT 007 RW 005 ', 'Ploso ', 'Tambak Sari ', 'Ploso 7/9 RT 007 RW 005 ', 'Ploso 7/9 RT 007 RW 005 ', '085730453106', 'Perseorangan ', 'NIB ', '0912210013253', 'Makanan ', 'Roti, kue pastry dan Gula gula ', 'bida 2 bakery ', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(88, 86, NULL, 'Dapur Canda', 'Wahyu Ida Rochyati', 'Perempuan ', '3578266412740001', '3578260101085201', 'Manyar Sabrangan 7/4 RT 002 RW 002 ', 'Manyar Sabrangan ', 'Mulyorejo ', 'Manyar Sabrangan 7/4 RT 002 RW 002 ', 'Manyar Sabrangan 7/4 RT 002 RW 002 ', '08819394045', 'Perseorangan ', 'NIB ', '2108240122144', 'Makanan ', 'Kue Basah dan Gado-Gado ', 'Dapur Canda', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(89, 87, NULL, 'Sabeluh ', 'Ninuk Ulfiani ', 'Perempuan ', '3578045710790009', '3578040201089296', 'Ngagel mulyo 1/32 RT 017 RW 004 ', 'Ngagelrejo ', 'Wonokromo ', 'Ngagel mulyo 1/32 RT 017 RW 004 ', 'Ngagel mulyo 1/32 RT 017 RW 004 ', '081235468889', 'Perseorangan ', 'NIB ', '1294001471392', 'Minuman', '	minuman yang terdiri dari campuran jus buah dan sayuran, 	air minum dalam kemasan, 	air minum dengan rasa, Minuman berbahan dasar buah, minuman buah, minuman rasa buah', 'sabeluh', '32', 1, 'Rp7.000.000,00', NULL, NULL, NULL),
(90, 88, NULL, 'Donsu Bomboloni ', 'Dewi Setiorini ', 'Perempuan ', '3578295107890001', '3578172311090007', 'Bulak rukem timur 2-K/15 RT 002 RW 007 ', 'Bulak ', 'Bulak ', 'Bulak rukem timur 2-K/15 RT 002 RW 007 ', 'Bulak rukem timur 2-K/15 RT 002 RW 007 ', '089691695757', 'Perseorangan ', 'NIB ', '0112230058583', 'Makanan ', 'Donut, Kue Basah ', 'Donsu Bomboloni ', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(91, 89, NULL, 'Onde onde Seribu Wijen ', 'Alfinatul Hasanah ', 'Perempuan ', '3578115607930003', '3578112801150004', 'Gembong 3/5 RT 003 RW 004 ', 'Kapasan ', 'Simokerto ', 'Gembong 3/5 RT 003 RW 004 ', 'Gembong 3/5 RT 003 RW 004 ', '083857075759', 'Perseorangan ', 'NIB ', '2105240069673', 'Makanan ', 'Onde onde ', 'Onde onde Seribu Wijen ', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(92, 90, NULL, 'Hanny Kitchen ', 'Yuli Rachmawati ', 'Perempuan ', '3578104107890012', '3578100201120021', 'Bulak Setro 3 No 10 B RT 001 RW 005 ', 'Bulak ', 'Bulak ', 'Bulak Setro 3 No 10 B RT 001 RW 005 ', 'Bulak Setro 3 No 10 B RT 001 RW 005 ', '085815312434', 'Perseorangan ', 'NIB ', '2307220004037', 'Makanan ', 'Martabak ', 'Hanny Kitchen ', '30', 1, 'Rp5.500.000,00', NULL, NULL, NULL),
(93, 91, NULL, 'Kwita Bakery ', 'Tinah Agus Tini ', 'Perempuan ', '3578024502800004', '3578020405090007', 'Sidosermo 2 Blok D No 7 RT 002 RW 004 ', 'Sidosermo ', 'Wonocolo ', 'Sidosermo 2 Blok D No 7 RT 002 RW 004 ', 'Sidosermo 2 Blok D No 7 RT 002 RW 004 ', '085604086025', 'Perseorangan ', 'NIB ', '3012220028329', 'Makanan ', 'Kue Basah, Kue Kering', 'Kwita Bakery ', '30', 1, 'Rp7.500.000,00', NULL, NULL, NULL),
(94, 92, NULL, 'Lima lima Nasi Kotak ', 'Tanti Nia Sari ', 'Perempuan ', '3578045009830010', '3578020101083375', 'Bendul Merisi Gg Besar Selatan 55 E RT 003 RW 006 ', 'Bendul merisi ', 'wonocolo ', 'Bendul Merisi Gg Besar Selatan 55 E RT 003 RW 006 ', 'Bendul Merisi Gg Besar Selatan 55 E RT 003 RW 006 ', '081231485266', 'Perseorangan ', 'NIB ', '0210210004778', 'Makanan ', 'Nasi Kotak, Kue basah, Nasi Rames Gresik (Nasi Krawu), nasi kebuli, Nasi Ayam Rica Rica, Nasi Campur Bali, Nasi Katsu, Nasi Ayam Kemangi, Nasi gurih krengsengan Mercon, Nasi Rames, nasi bebek, Nasi Ayam Bakar Bumbu Rujak, Nasi Sapi Krengseng Mercon, Nasi krengsengan mercon,         Nasi Ayam Geprek Sambal Matah,         Nasi Ayam Goreng Kuning, Nasi Ayam Krispi', 'Lima lima nasi kotak ', '30', 2, 'Rp15.000.000,00', NULL, NULL, NULL),
(95, 93, NULL, 'Fal-Zen', 'Iffa Sugiarti', 'Perempuan', '3578154301680003', '3578151201240004', 'Tanjung Karang 1/8', 'Perak Barat', 'Krembangan', 'Tanjung Karang 1/8', 'Tanjung Karang 1/8', '087889978365', 'Perseorangan ', 'NIB ', '2910210036214', 'Fashion ', 'gelang, bukan dari logam mulia', 'Fal-Zen', '14', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(96, 94, NULL, 'Gerai Jeng E\'eng', 'Iffa Sugiarti', 'Laki - laki', '3578293108690002', '3578290101080144', 'Bulak Cumpat Timur 3/17', 'Bulak', 'Bulak', 'Bulak Cumpat Timur 3/17', 'Bulak Cumpat Timur 3/17', '085854514500', 'Perseorangan ', 'NIB ', '2312240067884', 'Makanan', 'Nasi Ayam Kemangi', 'Gerai Jeng E\'eng', '30', 1, 'Rp5.000.000,00', NULL, NULL, NULL),
(97, 95, NULL, 'Dapur Moms Rerey', 'Retno Wati', 'Perempuan', '3517105411900003', '3578292303150005', 'Bulak Kalitinjang Baru 2/101', 'Bulak', 'Bulak', 'Bulak Kalitinjang Baru 2/101', 'Bulak Kalitinjang Baru 2/101', '085792737916', 'Perseorangan ', 'NIB ', '0702230067353', 'Makanan', 'nasi kotak, Seduhan herbal berbahan dasar kunyit asam', 'Dapur Moms Rerey', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(98, 96, NULL, 'Toko Kerupuk Risma', 'Anafia Rahmawati', 'Perempuan', '3578296912910001', '3578290101084308', 'Jl. Sukolilo 1B/2B', 'Sukolilo Baru', 'Bulak', 'Jl. Sukolilo 1B/2B', 'Jl. Sukolilo 1B/2B', '08223336468', 'Perseorangan ', 'NIB ', '2608210022819', 'Makanan', 'hasil olahan ikan untuk makanan manusia', 'Toko Kerupuk Risma', '29', 1, 'Rp10.000.000,00', NULL, NULL, NULL),
(99, 97, NULL, 'Griya Eonni', 'Sri Astutik', 'Perempuan', '3578175012790001', '3578170101083993', 'Bogorami Selatan 5/15', 'Bulak', 'Bulak', 'Bogorami Selatan 5/15', 'Bogorami Selatan 5/15', '081357755001', 'Perseorangan ', 'NIB ', '0201250027804', 'Makanan', 'kue nastar', 'Griya Eonni', '30', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(100, 98, NULL, 'Sae Sari Kedelai', 'Wiyono', 'Laki - laki', '3578292004760003', '3578291509110001', 'Bulak Cumpat Utara 6 Blok 9', 'Bulak', 'Bulak', 'Bulak Cumpat Utara 6 Blok 9', 'Bulak Cumpat Utara 6 Blok 9', '085713491224', 'Perseorangan ', 'NIB ', '1210230085864', 'Minuman', 'Minuman sari kedelai', 'Sae Sari Kedelai', '32', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(101, 99, NULL, 'Cibuyam Suroboyo', 'Luluk Ainiyah', 'Perempuan ', '3578295409880001', '3578291210100004', 'Jl. Nambangan Perak 9', 'Kedung Cowek', 'Bulak', 'Jl. Nambangan Perak 9', 'Jl. Nambangan Perak 9', '085733832589', 'Perseorangan ', 'NIB ', '1216000323608', 'Makanan', 'ikan asin', 'Cibuyam Suroboyo', '29', 1, 'Rp4.000.000,00', NULL, NULL, NULL),
(102, 100, NULL, 'Arinta', 'Ari Nuryanti', 'Perempuan ', '3578104309720006', '3578100101087605', 'Setro Baru Utara 9/47', 'Dukuh Setro', 'Tambaksari', 'Setro Baru Utara 9/47', 'Setro Baru Utara 9/47', '085100538558', 'Perseorangan ', 'NIB ', '0220009362337', 'Makanan', '	kue kering', 'Arinta', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(103, 1, 263, 'Kedai Jajanan\'s Bu Thiwuk 808 ', 'Sunarti', 'PEREMPUAN', '3578064804600004', '3578060501082769', 'Patemon 3/66', 'Patemon', 'Sawahan', 'Patemon 3/66', 'Patemon 3/66', '85777845351', 'PERSEORANGAN', 'NIB ', '708230055435', 'Makanan', 'Kue Basah : Lemper, Nagasari, Risoles, Kue Kentang', 'Kedai Jajanan\'s Bu Thiwuk 808 ', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(104, 2, 264, 'tumbas jajan', 'Jella Rosa Ayu Jenika', 'PEREMPUAN', '357065106950001', '3578062811190006', 'Kedung Anyar 1/26-D RT 002 RW 012', 'Sawahan', 'Sawahan', 'Kedung Anyar 1/26-D RT 002 RW 012', 'Kedung Anyar 1/26-D RT 002 RW 012', '82229222055', 'PERSEORANGAN', 'NIB ', '2309220038254', 'Makanan', 'roti dan kueh', 'tumbas jajan', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(105, 3, 265, 'KSM Familiy', 'Sri Utari', 'PEREMPUAN', '3578066611730010', '3578060101080931', 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Banyu Urip Lor 10/68 RT 004 RW 006', '81223419108', 'PERSEORANGAN', 'NIB ', '1808220023973', 'Makanan', 'makanan catering', 'KSM Familiy', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(106, 4, 266, 'Dapur Mamabi', 'Andi Defi Trianti', 'PEREMPUAN', '3578066604820010', '3578060101083231', 'Haimun 14-A RT 001 RW 008', 'Sawahan', 'Sawahan', 'Haimun 14-A RT 001 RW 008', 'Haimun 14-A RT 001 RW 008', '81336442386', 'PERSEORANGAN', 'NIB ', '2203220044429', 'Makanan', 'Rujak cingur, Nasi daging sapi, nasi campur', 'Dapur Mamabi', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(107, 5, 262, 'Mentoel sawahan', 'Asmariani', 'PEREMPUAN', '3578064403680003', '3578060101082296', 'Wonokitri 2/123 RT 004 RW 001', 'Pakis ', 'Sawahan', 'Wonokitri 2/123 RT 004 RW 001', 'Wonokitri 2/123 RT 004 RW 001', '895321348181', 'PERSEORANGAN', 'NIB ', '903230069325', 'Makanan', 'Kue sus, kue lapis, risoles mayones (kue basah), kue kacang (kue kering)', 'Mentoel sawahan', '30', 1, 'Rp2.500.000,00', NULL, NULL, 'NOPEMBER'),
(108, 6, 268, 'bundaweny 16', 'weny indri hapsari', 'PEREMPUAN', '3578065009790001', '3578060201080318', 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Sawahan', 'Sawahan', 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Kedung Anyar 9/16 RT 008 RW 003  ', '81315531522', 'PERSEORANGAN', 'NIB ', '1403230045357', 'Makanan', 'Roti, kueh', 'bundaweny 16', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(109, 7, 269, 'Mie Ayam Pangsit Sidomulyo', 'Yeni Kustiah', 'PEREMPUAN', '3517056602900001', '3578062310170006', 'Simo Sidomulyo GG 4 No14', 'Petemon', 'Sawahan', 'Simo Sidomulyo GG 4 No14', 'Simo Sidomulyo GG 4 No14', '82331641822', 'PERSEORANGAN', 'NIB ', '312220006294', 'Makanan', 'Mie Ayam', 'Mie Ayam Pangsit Sidomulyo', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(110, 8, 270, 'Papin Foods And Drinks', 'Afia Khoiriza', 'PEREMPUAN', '3578064410730005', '3578060101088923', 'Simo Sidomulyo I/12A', 'Petemon', 'Sawahan', 'Simo Sidomulyo I/12A', 'Jalan Petemon III No.35B', '82142944593', 'PERSEORANGAN', 'NIB ', '2203220046218', 'Makanan', 'Mie Kotak, Nasi Telur Balado, Nasi Telur kecap, nasi krengsengan daging sapi', 'Papin Foods And Drinks', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(111, 9, 271, 'RR21', 'Hartatik', 'PEREMPUAN', '5271025801780001', '3578062610200009', 'Kembang Kuning Kramat 2/21-A', 'Pakis ', 'Sawahan', 'Kembang Kuning Kramat 2/21-A', 'Kembang Kuning Kramat 2/21-A', '859555141899', 'PERSEORANGAN', 'NIB ', '2706230055764', 'Makanan Minuman', 'Es Dawet, Es Campur, Es Cincau, Es Buah Jadul (air yang dibekukan), Keripik Laderan (keripik yang ditipiskan)', 'RR21', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(112, 10, 272, 'Bu Ncik', 'Sri Mulyati', 'PEREMPUAN', '3213126101780001', ' ', 'Dukuh Kupang Timur VI/3', 'Pakis ', 'Sawahan', 'Dukuh Kupang Timur VI/3', 'Dukuh Kupang Timur VI/3', '85334730967', 'PERSEORANGAN', 'NIB ', '1909210012057', 'Makanan', 'Siomay dan Batagor (Baso Tahu Goreng)', 'Bu Ncik', '29', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(113, 11, 273, 'Omah Klemben', 'Francisca Mimosa', 'PEREMPUAN', '3578066403750002', '3578062505220010', 'Pakis Tirtosari 10/9', 'Pakis ', 'Sawahan', 'Pakis Tirtosari 10/9', 'Pakis Tirtosari 10/9', '81358086683', 'PERSEORANGAN', 'NIB ', '411240065549', 'Makanan', 'Kue Pangsit China ( siomay campuran daging ayam dan udang), sambal bawang', 'Omah Klemben', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(114, 12, 274, 'DNCook', 'Pudjiati', 'PEREMPUAN', '3578066908860012', '3578060101089777', 'Banyu Urip Jaya 6/54', 'Putat Jaya', 'Sawahan', 'Banyu Urip Jaya 6/54', 'Banyu Urip Jaya 6/54', '081231377186', 'PERSEORANGAN', 'NIB ', '1312220057549', 'mAKANAN', 'nASI kOTAK, nASI tumpeng', 'DNCook', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(115, 13, 275, 'Dapur Yang Ti', 'Suherman', 'Laki Laki', '3578060606600009', '3578060501080592', 'Jl. Petemon 4 No.93', 'Petemon', 'Sawahan', 'Petemon 4 No.93', 'Petemon 4 No.93', '082142215909', 'PERSEORANGAN', 'NIB ', '2804240003145', 'Makanan', 'Nasi Kotak, Nasi Kuning, Nasi Campur, Nasi Ayam', 'Dapur Yang Ti', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(116, 14, 276, 'Fiza Collection', 'Irsyadyyah', 'PEREMPUAN', '3578065304950003', '2310240249862', 'Kedung Anyar 8/54-B', 'sawahan', 'sawahan', 'Kedung Anyar 8/54-B', 'Kedung Anyar 8/54-B', '089516499572', 'PERSEORANGAN', 'NIB ', '2310240249862', 'Fashion/Handicratf', 'Baju daur ulang, bucket bunga', NULL, '16', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(117, 15, 277, 'BDS(Bakoel Duren Soerabaja)', 'Emi Kusumandari', 'PEREMPUAN', '3578066205660004', '35780422031000221', 'Banyu Urip Kidul 2a/11', 'banyu urip', 'sawahan', 'Banyu Urip Kidul 2a/11', 'Banyu Urip Kidul 2a/11', '08817561929', 'PERSEORANGAN', 'NIB ', '2506240034058', 'Minuman', 'Ketan Durian , Esteler Durian', 'BDS(Bakoel Durian Soeranajan)', '30', 1, 'Rp4.500.000,00', NULL, NULL, NULL),
(118, 16, 278, 'Pari\'e Qu', 'Mariningsih', 'PEREMPUAN', '3578066111740007', '3578010201089945', 'Petemon 4/132a', 'petemon', 'sawahan', 'Petemon 4/132a', 'Petemon 4/132a', '081230333352', 'PERSEORANGAN', 'NIB ', '3005220036117', 'Makanan', 'Risoles, Pastel isi daging dan sayuran , bubur sagu mutiara', 'Pari\'e Qu', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(119, 17, 279, 'Kenari\'s KUKER', 'Kurniawati', 'PEREMPUAN', '3578064402820008', '3578060201080655', 'Banyurip wetan4/32', 'banyu urip', 'sawahan', 'Banyurip wetan4/32', 'Banyurip wetan4/32', '085748692784', 'PERSEORANGAN', 'NIB ', '1512210025567', 'Makanan', 'kue coklat almond, kue Nastar, kastengel', 'KENARI;S KUKER', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(120, 18, NULL, 'Bun\'s Craft', 'Sulistiyowati', 'PEREMPUAN', '3578066308720001', '3578060601088829', 'Kupang Gunung Jaya 3/29', 'Putat Jaya', 'sawahan', 'Kupang Gunung Jaya 3/29', 'Kupang Gunung Jaya 3/29', '082141146564', 'PERSEORANGAN', 'NIB ', '0202230065816', 'Kerajinan', 'Kotak Tisu, Tas, Aksesories, ', 'Bun\'s Craft', '20', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(121, 19, NULL, 'Dapoerbundhae99', 'Winarti', 'PEREMPUAN', '3578064208750004', '3578060101085936', 'Simo Gunung Kramat Selatan 2', 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Selatan 2', 'Simo Gunung Kramat Selatan 2', '085757538321', 'PERSEORANGAN', 'NIB ', '2607220050686', 'Makanan', 'Nasi Kotak, Nasi Tumpeng', 'Dapoerbundhae99', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(122, 20, NULL, 'Obiesh Cake', 'Sulis Setyowati', 'PEREMPUAN', '3578065012860002', '3578061706220004', 'Banyu Urip Kidul 5/59', 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 5/59', 'Banyu Urip Kidul 5/59', '085850750563', 'PERSEORANGAN', 'NIB ', '0808230067061', 'Makanan', 'Roti , Kue Brownies, Kue Bolen, Kue Donat', 'Obiesh Cake', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(123, 21, NULL, 'Nombusi', 'Susilowati', 'PEREMPUAN', '3578066601770006', '3578060501086374', 'Banyu Urip Lor 2/18', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 2/18', 'Banyu Urip Lor 2/18', '082140992407', 'PERSEORANGAN', 'NIB ', '2310240263832', 'Minuman', 'Kunyit asem, Beras kencur', 'Nombusi', '5', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(124, 22, NULL, 'Sarisol', 'Sari Mawardhany', 'PEREMPUAN', '3578064811730006', '3578060101082758', 'Banyu Urip Kidul 6G/8', 'banyu urip', 'Sawahan', 'Banyu Urip Kidul 6G/8', 'Banyu Urip Kidul 6G/8', '083830191515', 'PERSEORANGAN', 'NIB ', '0608240048272', 'makanan', 'risoles.', 'Sarisol', '30', 1, 'Rp. 2.000.000,-', NULL, NULL, NULL),
(125, 23, NULL, 'Svedanika', 'Ernawati', 'PEREMPUAN', '3578065104760007', '3578060101081506', 'Petemon 2/104-A', 'petemon', 'Sawahan', 'Petemon 2/104-A', 'Petemon 2/104-A', '085606606655', 'PERSEORANGAN', 'NIB ', '2607220058349', 'Makanan', 'Kue Basah,  Donar, Risoles', 'Svedanika', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL);
INSERT INTO `jumlah_umkm` (`id`, `no_urut`, `no`, `nama_usaha`, `nama_pelaku_usaha`, `jenis_kelamin`, `nik`, `kk`, `alamat_sesuai_ktp`, `kelurahan`, `kecamatan`, `alamat_domisili`, `alamat_tempat_usaha`, `no_telp`, `status_pengelolaan_usaha`, `legalitas_yang_dimiliki`, `nomor_legalitas`, `sektor_usaha`, `jenis_produk`, `nama_produk_merk`, `kelas_merek`, `jumlah_tenaga_kerja`, `omset_per_bulan`, `no_pendaftaran`, `status_pendaftaran`, `realisasi`) VALUES
(126, 24, NULL, '3 Putra 5758', 'Kukuh Prasetyo', 'Laki Laki', '3575021702820003', '3578060801200011', 'Putat Jaya C Timur III/15', 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur III/15', 'Putat Jaya C Timur III/15', '\'081952772274', 'PERSEORANGAN', 'NIB ', '2311230080228', 'Makanan', 'Roti, Kue, Kembang Gula', '3 Putra 5758', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(127, 25, NULL, 'Lilos\'s', 'Alvi Maghfiratul Laila', 'PEREMPUAN', '357317010710004', '3578312910220002', 'Queens Town Q I/57', 'sambikerep', 'sambikerep', 'Queens Town Q I/57', 'Queens Town Q I/57', '08113355772', 'PERSEORANGAN', 'NIB ', '2206220093782', 'Fashion', 'Pakaian Wanita', 'Lilos\'s', '25', 2, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(128, 26, NULL, 'Kedai Jajan caraki', 'Anggita Kenangsary', 'PEREMPUAN', '3578064107820010', '3578062301200109', 'Wonokitri 2 No.116', 'Pakis ', 'Sawahan', 'Wonokitri 2 No.116', 'Wonokitri 2 No.116', '081230786483', 'PERSEORANGAN', 'NIB ', '2709230079718', 'Makmin', 'Kue kering/kue basah', 'Kedai Jajan caraki', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(129, 27, NULL, 'D\'rezluck', 'Siti Nurmilah', 'PEREMPUAN', '3578144909900001', '3578142709190002', 'Balongsari Blok 4-G/5', 'Balongsari', 'Tandes', 'Balongsari Blok 4-G/5', 'Balongsari Blok 4-G/5', '085959915912', 'PERSEORANGAN', 'NIB ', '1208240037491', 'Kerajinan', 'Rajutan', 'D\'rezluck', '23', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(130, 28, NULL, 'Heru Fish Waffle', 'Heru Dharmawan', 'Laki Laki', '3578061602820007', '3578062407200004', 'Simo Gunung Kramat Timur 1/30', 'Putat Jaya', 'Sawahan', 'Simo Gunung Kramat Timur 1/30', 'Simo Gunung Kramat Timur 1/30', '081333243466', 'PERSEORANGAN', 'NIB ', '0901240063935', 'Makanan', 'Waffel', 'Heru Fish Waffle', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(131, 29, NULL, 'GLORIA88', 'Rendra Chrismatofan', 'Laki Laki', '\'3578061802840007', '3578062611090014', 'Dukuh pakis 6D1-B No.3', 'Pakis ', 'Sawahan', 'Dukuh pakis 6D1-B No.3', 'Dukuh pakis 6D1-B No.3', '081234857424', 'PERSEORANGAN', 'NIB ', '1403230056855', 'Makanan', 'Mie Ayam', 'GLORIA88', '43', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(132, 30, NULL, 'Warunguntur 77', 'Soemiyati', 'PEREMPUAN', '3578064303590008', '3578061904170003', 'Kranggang Pangselan 5/14 ', 'Sawahan', 'Sawahan', 'Kranggang Pangselan 5/14 ', 'Kranggang Pangselan 5/14 ', '082257776773', 'PERSEORANGAN', 'NIB ', '3578061904170003', 'Makanan', 'Nasi Campur', 'Warunguntur77', '30', 2, 'Rp2.500.000,00', NULL, NULL, NULL),
(133, 31, NULL, 'Zafir Style', 'Anik Masturin', 'PEREMPUAN', '\'3578065810780001', '3578060601088774', 'Petemon 2/84 B ', 'Petemon', 'Sawahan', 'Petemon 2/84 B ', 'Petemon 2/84 B ', '081333275655', 'PERSEORANGAN', 'NIB ', '2911240052609', 'Fashion', 'Kemeja Pria, Jas Pria', 'Zafir Style', '25', 2, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(134, 32, NULL, 'Pastelikah', 'Setyono', 'Laki Laki', '3578060905750005', '3578060201081779', 'Banyu Urip Lor 6/88', 'Kupang Krajan', 'Sawahan', 'Banyu Urip Lor 6/88', 'Banyu Urip Lor 6/88', '087852755388', 'PERSEORANGAN', 'NIB ', '3012230205498', 'Makanan', 'Pastel mini', 'Pastelikah', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(135, 33, NULL, 'EMAK SIMO', 'Soepinianti', 'PEREMPUAN', '3578065802610001', '3578060601083848', 'Simo Gunung 1/20', 'Banyu urip', 'Sawahan', 'Simo Gunung 1/20', 'Simo Gunung 1/20', '083830003029', 'PERSEORANGAN', 'NIB ', '2203220044238', 'makanan', 'Nasi Ayam Kecap, Nasi semur dll', 'EMAK SIMO', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(136, 34, NULL, 'NONA\'S FOOD', 'Elisda Hariyanti', 'PEREMPUAN', '3525166507920001', '3578060408150007', 'Girilaya 2/31', 'Banyu urip', 'Sawahan', 'Girilaya 2/31', 'Girilaya 2/31', '082139230529', 'PERSEORANGAN', 'NIB ', '2810240147594', 'Makanan', 'Ayam Geprek, Lumpiah Goreng', 'NONA\'S Food', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(137, 35, NULL, 'GENarta Collection', 'Silvia Ratnani', 'PEREMPUAN', '3525044103920001', '3578060704170008', 'Putat Jaya C Timur 3/3', 'Putat Jaya', 'Sawahan', 'Putat Jaya C Timur 3/3', 'Putat Jaya C Timur 3/3', '081357822559', 'PERSEORANGAN', 'NIB ', '2002220023085', 'Kerajinan', 'Flanel, Bucket', 'GENarta Collection', '16', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(138, 36, NULL, 'Sambal Bu Fatimah', 'Siti Fatimah', 'PEREMPUAN', '3578064608750001', '\'3578060101088372', 'Simo Gunung Baru Jaya Blok G1/10', 'Putat Jaya', 'Sawahan', 'Simo Gunung Baru Jaya Blok G1/10', 'Simo Gunung Baru Jaya Blok G1/10', '081235652676', 'PERSEORANGAN', 'NIB ', '2203220043487', 'Makanan', 'Ayam Geprek, Penyet', 'Sambal Bu Fatimah ', '29', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(139, 37, NULL, 'Oemah Daharan', 'Rosyta Aisyaroh Rahmawati P', 'PEREMPUAN', '3578064306950004', '\'3578060601220004', 'Kupang Gunung Timur 7vB/45', 'Putat Jaya', 'Sawahan', 'Kupang Gunung Timur 7 -B/45', 'Kupang Gunung Timur 7 -B/45', '087855549981', 'PERSEORANGAN', 'NIB ', '2005240040881', 'Makanan', 'Kue Pangsit Cina\' Nasi Ayam Geprek', 'Oemah Daharan', '30', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(140, 38, NULL, 'Mimi cakecookies', 'Surochmah', 'PEREMPUAN', '3578066406770001', '3578060201080217', 'Kembang Kuning Mulyo I No.4', 'Pakis ', 'Sawahan', 'Kembang Kuning Mulyo I No.4', 'Kembang Kuning Mulyo I No.4', '082233352380', 'PERSEORANGAN', 'NIB ', '2506220025719', 'Makanan', 'Kue Pai, Nastar, Kastangel, Semprit, Keju dll', 'Mimicakecookies', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(141, 39, NULL, 'Wastra Bag', 'Adhela Mahaswari Pikantara D', 'PEREMPUAN', '3578036107010008', '3578030101081697', 'Rungkut Kidul Lor RL 2C/29 ', 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '082131345066', 'PERSEORANGAN', 'NIB ', '0409240025273', 'Fashion', 'Tas, Dompet', 'Wastra Bag', '18', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(142, 40, NULL, 'Ellegant Batik', 'Nurul Ziana', 'PEREMPUAN', '3578035606680002', '3578030101081697', 'Rungkut Kidul Lor RL 2C/29 ', 'Kalirungkut ', 'Rungkut', 'Rungkut Kidul Lor RL 2C/29 ', 'Rungkut Kidul Lor RL 2C/29 ', '081334512300/0813315151', 'PERSEORANGAN', 'NIB ', '1295000603609', 'Fashion', 'Baju', 'Ellegant Batik', '25', 1, 'Rp. 5.000,000,-', NULL, NULL, NULL),
(143, 41, NULL, 'Lieng Ows Tee', 'Indah Surjani Goeyardi', 'PEREMPUAN', '3578066409760007', '3578021101190001', 'Bendulmerisi Selatan 3/15', 'Bendulmerisi ', 'wonocolo', 'Bendulmerisi Selatan 3/15', 'Bendulmerisi Selatan 3/15', '0821151111368', 'PERSEORANGAN', 'NIB ', '1908240076005', 'Kerajinan', 'Boneka Rajut', 'Lieng Ows Tee', '23', 1, 'Rp2.500.000,00', NULL, NULL, NULL),
(144, 42, NULL, 'Benyamin Yacob', 'Raditya Pratama Juwiandinanta', 'Laki Laki', '3978180705060001', '3578180101084243', 'Lakarsantri RT 2 RW 4', 'Lakarsantri', 'Lakarsantri', 'Lakarsantri RT 2 RW 4', 'Lakarsantri RT 2 RW 4', '081336956366', 'PERSEORANGAN', 'NIB ', '0302250042994', 'Fashion', 'Busana', 'Benyamin Yacob', '25', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(145, 43, NULL, 'Mai Co Tailor', 'Natasya Cornelia', 'PEREMPUAN', '3578206603010002', '3578200101083458', 'Royal Park 2 Blok TK 3-78', 'Lidah kulon', 'Lakarsantri', 'Royal Park 2 Blok TK 3-78', 'Royal Park 2 Blok TK 3-78', '081213819006', 'PERSEORANGAN', 'NIB ', '2210240275722', 'Fashion', 'Pakaian .', 'Mai Co Tailor', '5', 2, 'Rp4.500.000,00', NULL, NULL, NULL),
(146, 44, NULL, 'ZARARA BAKERY', 'Arie Wardiani SPd', 'PEREMPUAN', '3578076601750001', '\'3578302206190001', 'Griya Benowo Indah Blok C/7', 'Babat Jerawat ', 'Pakal', 'Griya Benowo Indah Blok C/7', 'Griya Benowo Indah Blok C/7', '087829722378', 'PERSEORANGAN', 'NIB ', '1407240028975', 'Makanan', 'Roti', 'ZARARA BAKERY', '30', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(147, 45, NULL, 'La Tea Es Teh jumbo', 'Lailatul Nuzul', 'PEREMPUAN', '3578046310720003', '3578046310720003', 'Ngagel Mulyo 16/65 B', 'Ngegel Rejo', 'Wonokromo', 'Ngagel Mulyo 16/65 B', 'Ngagel Mulyo 16/65 B', '082331445600', 'PERSEORANGAN', 'NIB ', '0508230021492', 'Minnuman', 'Es Teh', 'LA Tea Es Teh Jumbo', '30', 1, 'Rp3.000.000,00', NULL, NULL, NULL),
(148, 46, NULL, 'Cahaya Baru', 'Julius Alvaro Sumargo', 'Laki Laki', '3509060907050002', '3578082410190002', 'Mojoarum 2/6', 'Mojo ', 'Gubeng', 'Mojoarum 2/6', 'Mojoarum 2/6', '0895620107573', 'PERSEORANGAN', 'NIB ', '1202250100852', 'Makanan', 'Ayam goreng, ', 'Resep Makmuk', '29', 2, 'Rp3.000.000,00', NULL, NULL, NULL),
(149, 47, NULL, 'Dina Collection', 'Agust Nurdiana', 'PEREMPUAN', '3374025008750003', '3578150505150007', 'Kemayoran Masjid No.4', 'Krembangan Selatan ', 'Krembangan', 'Kemayoran Masjid No.4', 'Kemayoran Masjid No.4', '088226368757', 'PERSEORANGAN', 'NIB ', '3105220013326', 'Fashion ', 'Kain Ecoprint', 'K\'Din', '24', 1, 'Rp3.000.000,00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `kategori_produk`
--

CREATE TABLE `kategori_produk` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_kategori` varchar(100) NOT NULL,
  `kategori` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `kategori_produk`
--

INSERT INTO `kategori_produk` (`id`, `nama_kategori`, `kategori`) VALUES
(1, 'Makanan', NULL),
(2, 'Lain lain', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `sertifikasi_halal`
--

CREATE TABLE `sertifikasi_halal` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_pelaku_usaha` varchar(150) NOT NULL,
  `nama_umkm` varchar(150) NOT NULL,
  `nomor_sertifikat_halal` varchar(100) NOT NULL,
  `nomor_sertifikat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sertifikasi_halal`
--

INSERT INTO `sertifikasi_halal` (`id`, `nama_pelaku_usaha`, `nama_umkm`, `nomor_sertifikat_halal`, `nomor_sertifikat`) VALUES
(3, 'Siti Aminah', 'Dapoer Aminah', '', 'SH-001/2025'),
(4, 'Budi Santoso', 'Bakso Pak Budi', '', 'SH-002/2025');

-- --------------------------------------------------------

--
-- Table structure for table `sertifikasi_merek`
--

CREATE TABLE `sertifikasi_merek` (
  `id` int(11) NOT NULL,
  `jumlah_umkm_id` int(11) NOT NULL,
  `nama_brand` varchar(255) NOT NULL,
  `nomor_sertifikat_merek` varchar(100) DEFAULT NULL,
  `kelas_merek` varchar(50) DEFAULT NULL,
  `jenis_merek` enum('kata','logo','kombinasi') DEFAULT NULL,
  `status` enum('pengajuan','proses','diterbitkan','ditolak','kadaluarsa') NOT NULL DEFAULT 'pengajuan',
  `tgl_pengajuan` date DEFAULT NULL,
  `tgl_terbit` date DEFAULT NULL,
  `berlaku_sampai` date DEFAULT NULL,
  `catatan` text DEFAULT NULL,
  `file_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sertifikasi_merek`
--

INSERT INTO `sertifikasi_merek` (`id`, `jumlah_umkm_id`, `nama_brand`, `nomor_sertifikat_merek`, `kelas_merek`, `jenis_merek`, `status`, `tgl_pengajuan`, `tgl_terbit`, `berlaku_sampai`, `catatan`, `file_url`, `created_at`, `updated_at`) VALUES
(1, 1, 'Kedai Jajanan\'s Bu Thiwuk 808 ', 'IDM0000000001', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(2, 2, 'tumbas jajan', 'IDM0000000002', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(3, 3, 'KSM Familiy', 'IDM0000000003', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(4, 4, 'Dapur Mamabi', 'IDM0000000004', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(5, 5, 'Mentoel sawahan', 'IDM0000000005', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(6, 6, 'bundaweny 16', 'IDM0000000006', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(7, 7, 'Mie Ayam Pangsit Sidomulyo', 'IDM0000000007', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(8, 8, 'Papin Foods And Drinks', 'IDM0000000008', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(9, 9, 'RR21', 'IDM0000000009', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(10, 10, 'Bu Ncik', 'IDM0000000010', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(11, 11, 'Omah Klemben', 'IDM0000000011', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(12, 12, 'DNCook', 'IDM0000000012', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(13, 13, 'Dapur Yang Ti', 'IDM0000000013', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(14, 14, '', 'IDM0000000014', '16', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(15, 15, 'BDS(Bakoel Durian Soeranajan)', 'IDM0000000015', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(16, 16, 'Pari\'e Qu', 'IDM0000000016', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(17, 17, 'KENARI;S KUKER', 'IDM0000000017', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(18, 18, 'Bun\'s Craft', 'IDM0000000018', '20', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(19, 19, 'Dapoerbundhae99', 'IDM0000000019', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(20, 20, 'Obiesh Cake', 'IDM0000000020', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(21, 21, 'Nombusi', 'IDM0000000021', '5', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(22, 22, 'Sarisol', 'IDM0000000022', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(23, 23, 'Svedanika', 'IDM0000000023', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(24, 24, '3 Putra 5758', 'IDM0000000024', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(25, 25, 'Lilos\'s', 'IDM0000000025', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(26, 26, 'Kedai Jajan caraki', 'IDM0000000026', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(27, 27, 'D\'rezluck', 'IDM0000000027', '23', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(28, 28, 'Heru Fish Waffle', 'IDM0000000028', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(29, 29, 'GLORIA88', 'IDM0000000029', '43', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(30, 30, 'Warunguntur77', 'IDM0000000030', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(31, 31, 'Zafir Style', 'IDM0000000031', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(32, 32, 'Pastelikah', 'IDM0000000032', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(33, 33, 'EMAK SIMO', 'IDM0000000033', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(34, 34, 'NONA\'S Food', 'IDM0000000034', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(35, 35, 'GENarta Collection', 'IDM0000000035', '16', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(36, 36, 'Sambal Bu Fatimah ', 'IDM0000000036', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(37, 37, 'Oemah Daharan', 'IDM0000000037', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(38, 38, 'Mimicakecookies', 'IDM0000000038', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(39, 39, 'Wastra Bag', 'IDM0000000039', '18', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(40, 40, 'Ellegant Batik', 'IDM0000000040', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(41, 41, 'Lieng Ows Tee', 'IDM0000000041', '23', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(42, 42, 'Benyamin Yacob', 'IDM0000000042', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(43, 43, 'Mai Co Tailor', 'IDM0000000043', '5', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(44, 44, 'ZARARA BAKERY', 'IDM0000000044', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(45, 45, 'LA Tea Es Teh Jumbo', 'IDM0000000045', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(46, 46, 'Resep Makmuk', 'IDM0000000046', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(47, 47, 'K\'Din', 'IDM0000000047', '24', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(48, 48, 'Sastrarasa sebuah karya rasa', 'IDM0000000048', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(49, 49, 'Treepuspa', 'IDM0000000049', '16', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(50, 50, 'Griya Gemati ', 'IDM0000000050', '24', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(51, 52, 'Ben\'e-E Drink', 'IDM0000000051', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(52, 53, 'Bandengku Bandeng Presto Bendul Merisi', 'IDM0000000052', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(53, 54, 'Radjamoe', 'IDM0000000053', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(54, 55, 'Rutz', 'IDM0000000054', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(55, 56, 'ROTI BAKAR BRO-SIS ', 'IDM0000000055', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(56, 57, 'HEY Cincau!', 'IDM0000000056', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(57, 58, 'WIL ', 'IDM0000000057', '3', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(58, 59, 'Memoire Haus ', 'IDM0000000058', '24', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(59, 60, 'Auf Beauty ', 'IDM0000000059', '3', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(60, 61, 'Cendol With You ', 'IDM0000000060', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(61, 62, 'KAUDHAWA TEA ', 'IDM0000000061', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(62, 63, 'Zane ', 'IDM0000000062', '14', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(63, 64, 'Kopi Grobar ', 'IDM0000000063', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(64, 65, 'Dapur Mak R.A', 'IDM0000000064', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(65, 66, 'Rayu Manis ', 'IDM0000000065', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(66, 67, 'Dapur Budhe Dreamland ', 'IDM0000000066', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(67, 68, 'Dreamingland Snack ', 'IDM0000000067', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(68, 69, 'Sri Wijaya 46', 'IDM0000000068', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(69, 70, 'DJP Dapuer Dwi JP ', 'IDM0000000069', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(70, 71, 'Dapuer Mak Unik ', 'IDM0000000070', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(71, 72, 'SISERU ', 'IDM0000000071', '28', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(72, 73, 'Labaik Pizza ', 'IDM0000000072', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(73, 74, 'RAYFAN ', 'IDM0000000073', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(74, 75, 'Bilgharo Kitchen ', 'IDM0000000074', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(75, 76, 'Dapur Icha', 'IDM0000000075', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(76, 78, 'Sunduk\'an sate Kiandra ', 'IDM0000000076', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(77, 79, 'Mem Mem ', 'IDM0000000077', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(78, 80, 'DIMSUM DOM ', 'IDM0000000078', '43', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(79, 81, 'JURAGAN Kress & Sueger', 'IDM0000000079', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(80, 82, 'Kedai Bu Mega ', 'IDM0000000080', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(81, 83, 'Keripik singkong Mbak Ibad ', 'IDM0000000081', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(82, 84, 'ZUMI ', 'IDM0000000082', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(83, 85, 'POY ', 'IDM0000000083', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(84, 86, 'Sweettlekid', 'IDM0000000084', '25', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(85, 87, 'bida 2 bakery ', 'IDM0000000085', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(86, 88, 'Dapur Canda', 'IDM0000000086', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(87, 89, 'sabeluh', 'IDM0000000087', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(88, 90, 'Donsu Bomboloni ', 'IDM0000000088', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(89, 91, 'Onde onde Seribu Wijen ', 'IDM0000000089', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(90, 92, 'Hanny Kitchen ', 'IDM0000000090', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(91, 93, 'Kwita Bakery ', 'IDM0000000091', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(92, 94, 'Lima lima nasi kotak ', 'IDM0000000092', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(93, 95, 'Fal-Zen', 'IDM0000000093', '14', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(94, 96, 'Gerai Jeng E\'eng', 'IDM0000000094', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(95, 97, 'Dapur Moms Rerey', 'IDM0000000095', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(96, 98, 'Toko Kerupuk Risma', 'IDM0000000096', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(97, 99, 'Griya Eonni', 'IDM0000000097', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(98, 100, 'Sae Sari Kedelai', 'IDM0000000098', '32', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(99, 101, 'Cibuyam Suroboyo', 'IDM0000000099', '29', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(100, 102, 'Arinta', 'IDM0000000100', '30', NULL, 'pengajuan', NULL, NULL, NULL, NULL, NULL, '2025-09-21 20:14:50', '2025-09-21 20:52:36'),
(128, 51, '', 'IDM000000051', '30', 'kata', 'pengajuan', '2025-08-02', NULL, NULL, 'AUTO-DUMMY', NULL, '2025-09-21 20:18:45', '2025-09-21 20:18:45'),
(129, 77, '', 'IDM000000077', '43', 'kombinasi', 'diterbitkan', '2025-07-07', '2025-09-05', '2035-09-22', 'AUTO-DUMMY', NULL, '2025-09-21 20:18:45', '2025-09-21 20:18:45'),
(131, 2, 'tumbas jajan', 'IDM0000000131', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(132, 3, 'KSM Familiy', 'IDM0000000132', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(133, 4, 'Dapur Mamabi', 'IDM0000000133', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(134, 5, 'Mentoel sawahan', 'IDM0000000134', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(135, 6, 'bundaweny 16', 'IDM0000000135', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(136, 7, 'Mie Ayam Pangsit Sidomulyo', 'IDM0000000136', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(137, 8, 'Papin Foods And Drinks', 'IDM0000000137', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(138, 9, 'RR21', 'IDM0000000138', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(139, 10, 'Bu Ncik', 'IDM0000000139', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(140, 11, 'Omah Klemben', 'IDM0000000140', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(141, 12, 'DNCook', 'IDM0000000141', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(142, 13, 'Dapur Yang Ti', 'IDM0000000142', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(143, 14, 'Fiza Collection', 'IDM0000000143', '16', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(144, 15, 'BDS(Bakoel Durian Soeranajan)', 'IDM0000000144', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(145, 16, 'Pari\'e Qu', 'IDM0000000145', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(146, 17, 'KENARI;S KUKER', 'IDM0000000146', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(147, 18, 'Bun\'s Craft', 'IDM0000000147', '20', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(148, 19, 'Dapoerbundhae99', 'IDM0000000148', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(149, 20, 'Obiesh Cake', 'IDM0000000149', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(150, 21, 'Nombusi', 'IDM0000000150', '5', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(151, 22, 'Sarisol', 'IDM0000000151', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(152, 23, 'Svedanika', 'IDM0000000152', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(153, 24, '3 Putra 5758', 'IDM0000000153', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(154, 25, 'Lilos\'s', 'IDM0000000154', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(155, 26, 'Kedai Jajan caraki', 'IDM0000000155', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(156, 27, 'D\'rezluck', 'IDM0000000156', '23', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(157, 28, 'Heru Fish Waffle', 'IDM0000000157', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(158, 29, 'GLORIA88', 'IDM0000000158', '43', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(159, 30, 'Warunguntur77', 'IDM0000000159', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(160, 31, 'Zafir Style', 'IDM0000000160', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(161, 32, 'Pastelikah', 'IDM0000000161', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(162, 33, 'EMAK SIMO', 'IDM0000000162', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(163, 34, 'NONA\'S Food', 'IDM0000000163', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(164, 35, 'GENarta Collection', 'IDM0000000164', '16', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(165, 36, 'Sambal Bu Fatimah ', 'IDM0000000165', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(166, 37, 'Oemah Daharan', 'IDM0000000166', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(167, 38, 'Mimicakecookies', 'IDM0000000167', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(168, 39, 'Wastra Bag', 'IDM0000000168', '18', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(169, 40, 'Ellegant Batik', 'IDM0000000169', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(170, 41, 'Lieng Ows Tee', 'IDM0000000170', '23', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(171, 42, 'Benyamin Yacob', 'IDM0000000171', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(172, 43, 'Mai Co Tailor', 'IDM0000000172', '5', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(173, 44, 'ZARARA BAKERY', 'IDM0000000173', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(174, 45, 'LA Tea Es Teh Jumbo', 'IDM0000000174', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(175, 46, 'Resep Makmuk', 'IDM0000000175', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(176, 47, 'K\'Din', 'IDM0000000176', '24', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(177, 48, 'Sastrarasa sebuah karya rasa', 'IDM0000000177', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(178, 49, 'Treepuspa', 'IDM0000000178', '16', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(179, 50, 'Griya Gemati ', 'IDM0000000179', '24', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(180, 52, 'Ben\'e-E Drink', 'IDM0000000180', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(181, 53, 'Bandengku Bandeng Presto Bendul Merisi', 'IDM0000000181', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(182, 54, 'Radjamoe', 'IDM0000000182', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(183, 55, 'Rutz', 'IDM0000000183', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(184, 56, 'ROTI BAKAR BRO-SIS ', 'IDM0000000184', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(185, 57, 'HEY Cincau!', 'IDM0000000185', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(186, 58, 'WIL ', 'IDM0000000186', '3', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(187, 59, 'Memoire Haus ', 'IDM0000000187', '24', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(188, 60, 'Auf Beauty ', 'IDM0000000188', '3', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(189, 61, 'Cendol With You ', 'IDM0000000189', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(190, 62, 'KAUDHAWA TEA ', 'IDM0000000190', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(191, 63, 'Zane ', 'IDM0000000191', '14', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(192, 64, 'Kopi Grobar ', 'IDM0000000192', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(193, 65, 'Dapur Mak R.A', 'IDM0000000193', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(194, 66, 'Rayu Manis ', 'IDM0000000194', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(195, 67, 'Dapur Budhe Dreamland ', 'IDM0000000195', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(196, 68, 'Dreamingland Snack ', 'IDM0000000196', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(197, 69, 'Sri Wijaya 46', 'IDM0000000197', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(198, 70, 'DJP Dapuer Dwi JP ', 'IDM0000000198', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(199, 71, 'Dapuer Mak Unik ', 'IDM0000000199', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(200, 72, 'SISERU ', 'IDM0000000200', '28', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(201, 73, 'Labaik Pizza ', 'IDM0000000201', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(202, 74, 'RAYFAN ', 'IDM0000000202', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(203, 75, 'Bilgharo Kitchen ', 'IDM0000000203', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(204, 76, 'Dapur Icha', 'IDM0000000204', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(205, 78, 'Sunduk\'an sate Kiandra ', 'IDM0000000205', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(206, 79, 'Mem Mem ', 'IDM0000000206', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(207, 80, 'DIMSUM DOM ', 'IDM0000000207', '43', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(208, 81, 'JURAGAN Kress & Sueger', 'IDM0000000208', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(209, 82, 'Kedai Bu Mega ', 'IDM0000000209', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(210, 83, 'Keripik singkong Mbak Ibad ', 'IDM0000000210', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(211, 84, 'ZUMI ', 'IDM0000000211', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(212, 85, 'POY ', 'IDM0000000212', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(213, 86, 'Sweettlekid', 'IDM0000000213', '25', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(214, 87, 'bida 2 bakery ', 'IDM0000000214', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(215, 88, 'Dapur Canda', 'IDM0000000215', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(216, 89, 'sabeluh', 'IDM0000000216', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(217, 90, 'Donsu Bomboloni ', 'IDM0000000217', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(218, 91, 'Onde onde Seribu Wijen ', 'IDM0000000218', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(219, 92, 'Hanny Kitchen ', 'IDM0000000219', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(220, 93, 'Kwita Bakery ', 'IDM0000000220', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(221, 94, 'Lima lima nasi kotak ', 'IDM0000000221', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(222, 95, 'Fal-Zen', 'IDM0000000222', '14', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(223, 96, 'Gerai Jeng E\'eng', 'IDM0000000223', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(224, 97, 'Dapur Moms Rerey', 'IDM0000000224', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(225, 98, 'Toko Kerupuk Risma', 'IDM0000000225', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(226, 99, 'Griya Eonni', 'IDM0000000226', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(227, 100, 'Sae Sari Kedelai', 'IDM0000000227', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(228, 100, 'Sae Sari Kedelai', 'IDM0000000228', '32', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(229, 101, 'Cibuyam Suroboyo', 'IDM0000000229', '29', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36'),
(230, 102, 'Arinta', 'IDM0000000230', '30', NULL, 'pengajuan', '2025-09-22', NULL, NULL, NULL, NULL, '2025-09-21 20:52:16', '2025-09-21 20:52:36');

-- --------------------------------------------------------

--
-- Table structure for table `umkm_kategori`
--

CREATE TABLE `umkm_kategori` (
  `id` int(10) UNSIGNED NOT NULL,
  `jumlah_umkm_id` int(10) UNSIGNED NOT NULL,
  `kategori_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `umkm_kategori`
--

INSERT INTO `umkm_kategori` (`id`, `jumlah_umkm_id`, `kategori_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 3, 1),
(4, 4, 1),
(5, 5, 1),
(6, 6, 1),
(7, 7, 1),
(8, 8, 1),
(9, 9, 1),
(10, 10, 1),
(11, 11, 1),
(12, 12, 1),
(13, 13, 1),
(14, 14, 2),
(15, 15, 2),
(16, 16, 1),
(17, 17, 1),
(18, 18, 2),
(19, 19, 1),
(20, 20, 1),
(21, 21, 2),
(22, 22, 1),
(23, 23, 1),
(24, 24, 1),
(25, 25, 2),
(26, 26, 1),
(27, 27, 2),
(28, 28, 1),
(29, 29, 1),
(30, 30, 1),
(31, 31, 2),
(32, 32, 1),
(33, 33, 1),
(34, 34, 1),
(35, 35, 2),
(36, 36, 1),
(37, 37, 1),
(38, 38, 1),
(39, 39, 2),
(40, 40, 2),
(41, 41, 2),
(42, 42, 2),
(43, 43, 2),
(44, 44, 1),
(45, 45, 2),
(46, 46, 1),
(47, 47, 2),
(48, 48, 1),
(49, 49, 2),
(50, 50, 2),
(51, 51, 2),
(52, 52, 2),
(53, 53, 1),
(54, 54, 2),
(55, 55, 2),
(56, 56, 1),
(57, 57, 1),
(58, 58, 2),
(59, 59, 2),
(60, 60, 2),
(61, 61, 2),
(62, 62, 2),
(63, 63, 2),
(64, 64, 2),
(65, 65, 1),
(66, 66, 1),
(67, 67, 1),
(68, 68, 1),
(69, 69, 1),
(70, 70, 1),
(71, 71, 1),
(72, 72, 2),
(73, 73, 1),
(74, 74, 1),
(75, 75, 1),
(76, 76, 1),
(77, 77, 2),
(78, 78, 1),
(79, 79, 1),
(80, 80, 1),
(81, 81, 1),
(82, 82, 2),
(83, 83, 1),
(84, 84, 2),
(85, 85, 1),
(86, 86, 2),
(87, 87, 1),
(88, 88, 1),
(89, 89, 2),
(90, 90, 1),
(91, 91, 1),
(92, 92, 1),
(93, 93, 1),
(94, 94, 1),
(95, 95, 2),
(96, 96, 1),
(97, 97, 1),
(98, 98, 1),
(99, 99, 1),
(100, 100, 2),
(101, 101, 1),
(102, 102, 1);

-- --------------------------------------------------------

--
-- Table structure for table `umkm_nib`
--

CREATE TABLE `umkm_nib` (
  `id` int(10) UNSIGNED NOT NULL,
  `nama_orang` varchar(150) NOT NULL,
  `nama_umkm` varchar(200) NOT NULL,
  `nomor_nib` varchar(50) NOT NULL,
  `no_telp` varchar(50) DEFAULT NULL,
  `jumlah_umkm_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `umkm_nib`
--

INSERT INTO `umkm_nib` (`id`, `nama_orang`, `nama_umkm`, `nomor_nib`, `no_telp`, `jumlah_umkm_id`) VALUES
(1, 'Sunarti', 'Kedai Jajanan\'s Bu Thiwuk 808', '708230055435', '85777845351', 100),
(2, 'Jella Rosa Ayu Jenika', 'tumbas jajan', '2309220038254', '82229222055', 2),
(3, 'Sri Utari', 'KSM Familiy', '1808220023973', '81223419108', 3),
(4, 'Andi Defi Trianti', 'Dapur Mamabi', '2203220044429', '81336442386', 4),
(5, 'Asmariani', 'Mentoel sawahan', '903230069325', '895321348181', 5),
(6, 'weny indri hapsari', 'bundaweny 16', '1403230045357', '81315531522', 6),
(7, 'Yeni Kustiah', 'Mie Ayam Pangsit Sidomulyo', '312220006294', '82331641822', 7),
(8, 'Afia Khoiriza', 'Papin Foods And Drinks', '2203220046218', '82142944593', 8),
(9, 'Hartatik', 'RR21', '2706230055764', '859555141899', 9),
(10, 'Sri Mulyati', 'Bu Ncik', '1909210012057', '85334730967', 10),
(11, 'Francisca Mimosa', 'Omah Klemben', '411240065549', '81358086683', 11),
(12, 'Pudjiati', 'DNCook', '1312220057549', '081231377186', 12),
(13, 'Suherman', 'Dapur Yang Ti', '2804240003145', '082142215909', 13),
(14, 'Irsyadyyah', 'Fiza Collection', '2310240249862', '089516499572', 14),
(15, 'Emi Kusumandari', 'BDS(Bakoel Duren Soerabaja)', '2506240034058', '08817561929', 15),
(16, 'Mariningsih', 'Pari\'e Qu', '3005220036117', '081230333352', 16),
(17, 'Kurniawati', 'Kenari\'s KUKER', '1512210025567', '085748692784', 17),
(18, 'Sulistiyowati', 'Bun\'s Craft', '0202230065816', '082141146564', 18),
(19, 'Winarti', 'Dapoerbundhae99', '2607220050686', '085757538321', 19),
(20, 'Sulis Setyowati', 'Obiesh Cake', '0808230067061', '085850750563', 20),
(21, 'Susilowati', 'Nombusi', '2310240263832', '082140992407', 21),
(22, 'Sari Mawardhany', 'Sarisol', '0608240048272', '083830191515', 22),
(23, 'Ernawati', 'Svedanika', '2607220058349', '085606606655', 23),
(24, 'Kukuh Prasetyo', '3 Putra 5758', '2311230080228', '\'081952772274', 24),
(25, 'Alvi Maghfiratul Laila', 'Lilos\'s', '2206220093782', '08113355772', 25),
(26, 'Anggita Kenangsary', 'Kedai Jajan caraki', '2709230079718', '081230786483', 26),
(27, 'Siti Nurmilah', 'D\'rezluck', '1208240037491', '085959915912', 27),
(28, 'Heru Dharmawan', 'Heru Fish Waffle', '0901240063935', '081333243466', 28),
(29, 'Rendra Chrismatofan', 'GLORIA88', '1403230056855', '081234857424', 29),
(30, 'Soemiyati', 'Warunguntur 77', '3578061904170003', '082257776773', 30),
(31, 'Anik Masturin', 'Zafir Style', '2911240052609', '081333275655', 31),
(32, 'Setyono', 'Pastelikah', '3012230205498', '087852755388', 32),
(33, 'Soepinianti', 'EMAK SIMO', '2203220044238', '083830003029', 33),
(34, 'Elisda Hariyanti', 'NONA\'S FOOD', '2810240147594', '082139230529', 34),
(35, 'Silvia Ratnani', 'GENarta Collection', '2002220023085', '081357822559', 35),
(36, 'Siti Fatimah', 'Sambal Bu Fatimah', '2203220043487', '081235652676', 36),
(37, 'Rosyta Aisyaroh Rahmawati P', 'Oemah Daharan', '2005240040881', '087855549981', 37),
(38, 'Surochmah', 'Mimi cakecookies', '2506220025719', '082233352380', 38),
(39, 'Adhela Mahaswari Pikantara D', 'Wastra Bag', '0409240025273', '082131345066', 39),
(40, 'Nurul Ziana', 'Ellegant Batik', '1295000603609', '081334512300/0813315151', 40),
(41, 'Indah Surjani Goeyardi', 'Lieng Ows Tee', '1908240076005', '0821151111368', 41),
(42, 'Raditya Pratama Juwiandinanta', 'Benyamin Yacob', '0302250042994', '081336956366', 42),
(43, 'Natasya Cornelia', 'Mai Co Tailor', '2210240275722', '081213819006', 43),
(44, 'Arie Wardiani SPd', 'ZARARA BAKERY', '1407240028975', '087829722378', 44),
(45, 'Lailatul Nuzul', 'La Tea Es Teh jumbo', '0508230021492', '082331445600', 45),
(46, 'Julius Alvaro Sumargo', 'Cahaya Baru', '1202250100852', '0895620107573', 46),
(47, 'Agust Nurdiana', 'Dina Collection', '3105220013326', '088226368757', 47),
(48, 'Nurullina Puspasari', 'Sastarasa Sebuah Karya rasa', '0411240092641', '082142773005', 48),
(49, 'Tria Agustin Nugrahini , SE', 'Treepuspa', '0268010140133', '087854446874', 49),
(50, 'Arief Budiman', 'Griya Gemati', '1810220244225', '08155116119', 50),
(51, 'Wahjudi Utomo MDRS Ak', 'Ben\'e-E Drink', '1202220016167', '081315380790', 52),
(52, 'Supaekan Siswanto', 'Bandengku Bandeng Presto Bendul', '2812220021478', '082337870972', 53),
(53, 'Dyah Wahyu  Pratiwi', 'Radjamoe', '2611210010918', '082230769726', 54),
(54, 'Sri Hartatik', 'Glant & Co', '1209000700736', '081331488441', 55),
(55, 'Hardini Vika Titasari', 'Roti Bakar BRO-SIS', '0810240120904', '082257668188', 56),
(56, 'Nandjar Wiludjeng', 'HEY Cincau!', '2212210016146', '082141560201', 57),
(57, 'Endi Putranto', 'WIL', '0102240035565', '085102242289', 58),
(58, 'Anastasia Marin Purnama', 'Memoire Haus', '0303250043491', '08113545227', 59),
(59, 'Tria Gustina Setiani, S.Psi', 'Auf Beauty', '2012230034067', '08123251029', 60),
(60, 'Anny Setyorini, SE', 'Cendol With You', '2105230021268', '0895429763355', 61),
(61, 'Alfan Bramestia', 'Kaudhawa Tea', '1205240054213', '081234468480', 62),
(62, 'Novia Fadhilah Zain', 'Zane', '2505230054262', '081249716911', 63),
(63, 'Rudyk Hermawan', 'Kopi Grobar', '0510230031616', '082142043600', 64),
(64, 'Trisia Indra Sarie', 'Dapur Mak R.A', '1295000620676', '081235755770', 65),
(65, 'Citra Purba Erwina, ST', 'Rayu Manis', '1274000602289', '081231177447', 66),
(66, 'Ririn Pujiati', 'Dapur Budhe Dreamland', '0610220031616', '087747778568', 67),
(67, 'Suprihayu Prinaryanti', 'Dreamingland Snacks', '1602230031353', '081252843750', 68),
(68, 'Sridiningsih', 'Sri Wijaya 46', '1210210036845', '081234668274', 69),
(69, 'Dwi Astutik', 'DJP Dapuer Dwi JP', '2402220020933', '083833584130', 70),
(70, 'Uniek Rinawati', 'Dapur Mak Uniek', '2105240091113', '08970890886', 71),
(71, 'Rahmi Reiza Caesarina', 'Siseru', '0909240088247', '087763335481', 72),
(72, 'Nanik Silverasudarwati', 'LABAIK PIZZA', '3105220047923', '085156888970', 73),
(73, 'Rini Mahmudah', 'RAYFAN', '1292001421583', '081235402058', 74),
(74, 'Mira Kustiyah', 'Bilgharo Kitchen', '1603220021124', '087761613469', 75),
(75, 'Solichah', 'Dapur Icha', '1701230060489', '087761801988', 76),
(76, 'Tina Purwati', 'sunduk\'an sate kiandra', '3110230136895', '08999372988', 78),
(77, 'Samuel Herman N Matulessy', 'Mem Mem', '2403250042039', '082233360045', 79),
(78, 'Dedy Purwanto', 'Dimsum Dom', '2012210022174', '081336351679/ 081290071626', 80),
(79, 'Haryo Bagus Prasmono', 'Juragan Kress& Sueger', '2610220035503', '082230433827', 81),
(80, 'Maria Megawati', 'Kedai Bu Mega', '2905230024342', '08123530641', 82),
(81, 'Badriyah Kamilah', 'Kripik Singkong Mbak Ibad', '1701250064341', '081916817409', 83),
(82, 'Monica Hartono', 'Zumi', '0711240112163', '08113393663', 84),
(83, 'Catur Ayu Wulandari', 'POY', '1412210019558', '0895805314395', 85),
(84, 'Rohdian Syah', 'Sweettlekid', '1302250107492', '081216711561', 86),
(85, 'Dwi Sriana Juda Astuti', 'Bida 2 Bakery', '0912210013253', '085730453106', 87),
(86, 'Wahyu Ida Rochyati', 'Dapur Canda', '2108240122144', '08819394045', 88),
(87, 'Ninuk Ulfiani', 'Sabeluh', '1294001471392', '081235468889', 89),
(88, 'Dewi Setiorini', 'Donsu Bomboloni', '0112230058583', '089691695757', 90),
(89, 'Alfinatul Hasanah', 'Onde onde Seribu Wijen', '2105240069673', '083857075759', 91),
(90, 'Yuli Rachmawati', 'Hanny Kitchen', '2307220004037', '085815312434', 92),
(91, 'Tinah Agus Tini', 'Kwita Bakery', '3012220028329', '085604086025', 93),
(92, 'Tanti Nia Sari', 'Lima lima Nasi Kotak', '0210210004778', '081231485266', 94),
(93, 'Iffa Sugiarti', 'Fal-Zen', '2910210036214', '087889978365', 95),
(94, 'Iffa Sugiarti', 'Gerai Jeng E\'eng', '2312240067884', '085854514500', 96),
(95, 'Retno Wati', 'Dapur Moms Rerey', '0702230067353', '085792737916', 97),
(96, 'Anafia Rahmawati', 'Toko Kerupuk Risma', '2608210022819', '08223336468', 98),
(97, 'Sri Astutik', 'Griya Eonni', '0201250027804', '081357755001', 99),
(98, 'Wiyono', 'Sae Sari Kedelai', '1210230085864', '085713491224', 100),
(99, 'Luluk Ainiyah', 'Cibuyam Suroboyo', '1216000323608', '085733832589', 101),
(100, 'Ari Nuryanti', 'Arinta', '0220009362337', '085100538558', 102);

-- --------------------------------------------------------

--
-- Table structure for table `umkm_peken`
--

CREATE TABLE `umkm_peken` (
  `no` int(10) UNSIGNED DEFAULT NULL,
  `nama_orang` varchar(255) DEFAULT NULL,
  `nama_umkm` int(11) NOT NULL,
  `kelurahan` varchar(225) NOT NULL,
  `kecamatan` varchar(225) NOT NULL,
  `nama_orang_fix` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `umkm_peken`
--

INSERT INTO `umkm_peken` (`no`, `nama_orang`, `nama_umkm`, `kelurahan`, `kecamatan`, `nama_orang_fix`) VALUES
(NULL, NULL, 1, 'Patemon 3/66', 'Patemon', NULL),
(NULL, NULL, 2, 'Kedung Anyar 1/26-D RT 002 RW 012', 'Sawahan', NULL),
(NULL, NULL, 3, 'Banyu Urip Lor 10/68 RT 004 RW 006', 'Kupang Krajan', NULL),
(NULL, NULL, 4, 'Haimun 14-A RT 001 RW 008', 'Sawahan', NULL),
(NULL, NULL, 5, 'Wonokitri 2/123 RT 004 RW 001', 'Pakis ', NULL),
(NULL, NULL, 6, 'Kedung Anyar 9/16 RT 008 RW 003  ', 'Sawahan', NULL),
(NULL, NULL, 7, 'Simo Sidomulyo GG 4 No14', 'Petemon', NULL),
(NULL, NULL, 8, 'Simo Sidomulyo I/12A', 'Petemon', NULL),
(NULL, NULL, 9, 'Kembang Kuning Kramat 2/21-A', 'Pakis ', NULL),
(NULL, NULL, 10, 'Dukuh Kupang Timur VI/3', 'Pakis ', NULL),
(NULL, NULL, 11, 'Pakis Tirtosari 10/9', 'Pakis ', NULL),
(NULL, NULL, 12, 'Banyu Urip Jaya 6/54', 'Putat Jaya', NULL),
(NULL, NULL, 13, 'Jl. Petemon 4 No.93', 'Petemon', NULL),
(NULL, NULL, 14, 'Kedung Anyar 8/54-B', 'sawahan', NULL),
(NULL, NULL, 15, 'Banyu Urip Kidul 2a/11', 'banyu urip', NULL),
(NULL, NULL, 16, 'Petemon 4/132a', 'petemon', NULL),
(NULL, NULL, 17, 'Banyurip wetan4/32', 'banyu urip', NULL),
(NULL, NULL, 18, 'Kupang Gunung Jaya 3/29', 'Putat Jaya', NULL),
(NULL, NULL, 19, 'Simo Gunung Kramat Selatan 2', 'Putat Jaya', NULL),
(NULL, NULL, 20, 'Banyu Urip Kidul 5/59', 'banyu urip', NULL);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_jumlah_kategori_produk`
-- (See below for the actual view)
--
CREATE TABLE `v_jumlah_kategori_produk` (
`kategori` varchar(17)
,`jumlah` bigint(21)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_sertifikasi_halal`
-- (See below for the actual view)
--
CREATE TABLE `v_sertifikasi_halal` (
`id` int(10) unsigned
,`nama_pelaku_usaha` varchar(150)
,`nama_umkm` varchar(150)
,`nomor_sertifikat` varchar(100)
);

-- --------------------------------------------------------

--
-- Structure for view `v_jumlah_kategori_produk`
--
DROP TABLE IF EXISTS `v_jumlah_kategori_produk`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_jumlah_kategori_produk`  AS SELECT CASE WHEN lcase(coalesce(`jumlah_umkm`.`jenis_produk`,'')) like '%makan%' OR lcase(coalesce(`jumlah_umkm`.`jenis_produk`,'')) like '%minum%' THEN 'Makanan & Minuman' ELSE 'Lain-lain' END AS `kategori`, count(0) AS `jumlah` FROM `jumlah_umkm` GROUP BY CASE WHEN lcase(coalesce(`jumlah_umkm`.`jenis_produk`,'')) like '%makan%' OR lcase(coalesce(`jumlah_umkm`.`jenis_produk`,'')) like '%minum%' THEN 'Makanan & Minuman' ELSE 'Lain-lain' END ;

-- --------------------------------------------------------

--
-- Structure for view `v_sertifikasi_halal`
--
DROP TABLE IF EXISTS `v_sertifikasi_halal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sertifikasi_halal`  AS SELECT `sertifikasi_halal`.`id` AS `id`, `sertifikasi_halal`.`nama_pelaku_usaha` AS `nama_pelaku_usaha`, `sertifikasi_halal`.`nama_umkm` AS `nama_umkm`, `sertifikasi_halal`.`nomor_sertifikat` AS `nomor_sertifikat` FROM `sertifikasi_halal` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jumlah umkm binaan`
--
ALTER TABLE `jumlah umkm binaan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `kelurahan` (`kelurahan`),
  ADD KEY `kecamatan` (`kecamatan`);

--
-- Indexes for table `jumlah_pedagang_swk`
--
ALTER TABLE `jumlah_pedagang_swk`
  ADD PRIMARY KEY (`nama_orang`);

--
-- Indexes for table `jumlah_umkm`
--
ALTER TABLE `jumlah_umkm`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_nama` (`nama_kategori`);

--
-- Indexes for table `sertifikasi_halal`
--
ALTER TABLE `sertifikasi_halal`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_no` (`nomor_sertifikat`);

--
-- Indexes for table `sertifikasi_merek`
--
ALTER TABLE `sertifikasi_merek`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_nomor` (`nomor_sertifikat_merek`),
  ADD KEY `idx_umkm` (`jumlah_umkm_id`),
  ADD KEY `idx_status` (`status`);

--
-- Indexes for table `umkm_kategori`
--
ALTER TABLE `umkm_kategori`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_umkm_kategori` (`jumlah_umkm_id`,`kategori_id`),
  ADD KEY `idx_umkm` (`jumlah_umkm_id`),
  ADD KEY `idx_kategori` (`kategori_id`);

--
-- Indexes for table `umkm_nib`
--
ALTER TABLE `umkm_nib`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_nib` (`nomor_nib`),
  ADD KEY `idx_umkm` (`jumlah_umkm_id`);

--
-- Indexes for table `umkm_peken`
--
ALTER TABLE `umkm_peken`
  ADD PRIMARY KEY (`nama_umkm`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jumlah umkm binaan`
--
ALTER TABLE `jumlah umkm binaan`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `jumlah_pedagang_swk`
--
ALTER TABLE `jumlah_pedagang_swk`
  MODIFY `nama_orang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=177;

--
-- AUTO_INCREMENT for table `jumlah_umkm`
--
ALTER TABLE `jumlah_umkm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;

--
-- AUTO_INCREMENT for table `kategori_produk`
--
ALTER TABLE `kategori_produk`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `sertifikasi_halal`
--
ALTER TABLE `sertifikasi_halal`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sertifikasi_merek`
--
ALTER TABLE `sertifikasi_merek`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `umkm_kategori`
--
ALTER TABLE `umkm_kategori`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- AUTO_INCREMENT for table `umkm_nib`
--
ALTER TABLE `umkm_nib`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `umkm_peken`
--
ALTER TABLE `umkm_peken`
  MODIFY `nama_umkm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sertifikasi_merek`
--
ALTER TABLE `sertifikasi_merek`
  ADD CONSTRAINT `fk_merek_umkm` FOREIGN KEY (`jumlah_umkm_id`) REFERENCES `jumlah_umkm` (`id`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
